import axios from "axios"
import { baseUrl } from "../../Server/baseUrl"
import { myAxios } from "../../Server/MyAxios"
import dayjs from "dayjs"
import { PageSize } from "../../Server/PageSize"

export const BiometricServiceModule={

    biometricDataUpload: async function(file){
        let data=null
        await myAxios.post(`biometric/add-file`,{"file":file}).then((res)=>{data=res})

           return data
    },
    getAllBiometricReportNonLate:async function(startDate,endDate){
       
        return await myAxios.get(`/biometric/get-all-biometric-report/calculated-report/${startDate}/${endDate}?${PageSize}`).then((res)=>res.data)
    },
    getAllBiometricDataViaEmpIdStartDateEndDate:async function(empId,startDate,endDate){

        return await myAxios.get(`/biometric/get-biometric-report-empid-fromdate-todate/${empId}/${startDate}/${endDate}?${PageSize}`).then((res)=>res.data)
    },

    getAllBiometricReportIsLate:async function(startDate,endDate){
       
        return await myAxios.get(`/biometric/get-all-biometric-report/calculated-report/${startDate}/${endDate}?${PageSize}`).then((res)=>res.data)
    },
    getAllBiometricReportAfterClickingView:async function(empId,startDate,endDate){
       
        return await myAxios.get(`/biometric/get-biometric-data-by-id-date/${empId}/${startDate}/${endDate}?${PageSize}`).then((res)=>res.data)
    },
    
    updateIsLateReport:async function(){
        return await myAxios.put(`/biometric/update-islate-report/2023-01-01/2023-07-01`).then((res)=>res.data)
    }


}