import * as React from 'react';
// import './em.css'
import { 
  Box,
  Grid, 
   Paper,
   Typography,
        } from "@mui/material";
import {FcBusinessman} from "react-icons/fc";
import { DataGrid } from '@mui/x-data-grid';
import { Button } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { Navigate, useNavigate } from 'react-router';
import {Divider} from '@mui/material';
import {Container} from '@mui/material';
import Person4Icon from '@mui/icons-material/Person4';
import {IconButton} from '@mui/material';
import { Delete } from '@mui/icons-material';
import { getReportingManagerTable } from '../../Services/employee-service/EmployeeService';
import { toast } from 'react-toastify'
import Loading from "../../Components/LoadingComponent/Loading";
import { useState } from 'react';
import moment from 'moment';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import { helpFunction } from '../HelperComponent/helpFunction';
import Brightness1Icon from '@mui/icons-material/Brightness1';
import PreviewIcon from '@mui/icons-material/Preview';

const columns = [
  { 
    field: 'empId',
   headerName: 'Employee Id', 
   width: 125,
    flex:2,
   headerClassName:'table-header'
 
  },
 
  { 
    field: 'biometricDate',
   headerName: 'Biometric Date', 
   width: 200,
    flex:2,
   headerClassName:'table-header',
   valueFormatter: params => 
   {
    let biometricDate=""
    if(params?.value!==null){
     biometricDate=moment(params?.value).format("DD/MM/YYYY")
    return biometricDate
    }
 else{
   return null
 }
   }

  },
  { 
    field: 'checkInTime',
   headerName: 'CheckIn Time', 
   width: 295,
    flex:2,
   headerClassName:'table-header',
   valueFormatter: params => 
   {
    let checkInTime=""
    if(params?.value!==null){
     checkInTime=params?.value.slice(11,16)
    return checkInTime
    }
 else{
   return null
 }
   }

   
  },
  { 
    field: 'checkOutTime',
   headerName: 'Checkout Time', 
   width: 295,
    flex:2,
   headerClassName:'table-header',
   valueFormatter: params => 
   {
    let checkOutTime=""
    if(params?.value!==null){
     checkOutTime=params?.value.slice(11,16)
    return checkOutTime
    }
 else{
   return null
 }
} 
  },

  { 
  field: 'totalWorkingTime',
   headerName: 'Total Working Time(In Mins)', 
   width: 300,
    flex:2,
   headerClassName:'table-header',
   valueFormatter: params => {
    return  params?.value +" Mins"
   }
   
   
  },
  
  { 
    field: 'modifiedOn',
   headerName: 'Modified On', 
   width: 125,
    flex:2,
   headerClassName:'table-header',
   valueFormatter: params => 
   {
    let modifiedOn=""
    if(params?.value!==null){
     modifiedOn=moment(params?.value).format("DD/MM/YYYY")
    return modifiedOn
    }
 else{
   return null
 }
   }
  },
  { 
    field: 'month',
   headerName: 'Month', 
   width: 125,
    flex:2,
   headerClassName:'table-header',
   renderCell: (params) => {
     
    return helpFunction.MonthShowing(params.formattedValue)
   
   }
   
  },
  { 
    field: 'year',
   headerName: 'Year', 
   width: 125,
    flex:2,
   headerClassName:'table-header'
   
  },
  { 
    field: 'isLate',
    headerName: 'Late', 
    width: 125,
    flex:2,
    headerClassName:'table-header',
    renderCell: (params)=>{
 
     if(params.formattedValue){
       return (
         <Box sx={{backgroundColor:"yellow",width:"40px",justifyContent:"center",display:"flex",height:"20px",alignContent:"center",alignItems:"center",borderRadius:"10px"}}>
  <Typography  sx={{color:"blue"}}> Yes</Typography>
         </Box>
       
     )
       
     }
     return (
       <Box sx={{backgroundColor:"green",width:"40px",justifyContent:"center",display:"flex",height:"20px",alignContent:"center",alignItems:"center",borderRadius:"10px"}}>
        <Typography sx={{color:"#FFFFFF"}} >No</Typography>
      </Box>
     )
 
    }
 
 
   },
  { 
     field: 'veryLate',
    headerName: 'Verylate',
    width: 125,
     flex:2,
    headerClassName:'table-header',
    renderCell: (params)=>{
 
     if(params.formattedValue){
       return (
         <Box sx={{backgroundColor:"#d50000",width:"40px",justifyContent:"center",display:"flex",height:"20px",alignContent:"center",alignItems:"center",borderRadius:"10px"}}>
         <Typography sx={{color:"yellow"}} >Yes</Typography>
         </Box>
     )
       
     }
     return (
       <Box sx={{backgroundColor:"green",width:"40px",justifyContent:"center",display:"flex",height:"20px",alignContent:"center",alignItems:"center",borderRadius:"10px"}}>
       <Typography sx={{color:"#FFFFFF"}} > No</Typography>
       </Box>
     )
 
    }
    
   },
   {
    field: 'View',
    headerName: 'View',
    width: 140,
    flex:2,
    headerClassName: 'table-header',
    renderCell: (params) => {
      
      
      return (
        <Box sx={{
            display: 'flex',
            justifyContent: 'center'
        }}>
            <IconButton variant="contained" color='error'>
           <PreviewIcon  color='secondary' sx={{marginRight:"39px"}}/>
           </IconButton >

        </Box>
    );

    }
}

];


export default function BiometricTable(props) {

  const [biometricTable1,setBiometricTable1]=React.useState([])
  const navigate=useNavigate()
  const[isLoading,setIsLoading]=useState(true)
let Data=props.biometricdata

  React.useEffect(()=>{

   setBiometricTable1(Data)
    
  },[Data])

//backbutton
const backbutton=useNavigate()
const handleRowClick=(params)=>{
  backbutton(`../Biometric-Table-After-Clicking-View`,{state:params.row.empId})
}

  return (
    
    <Box sx={{
        height: 200,
        width: '75vw',
        padding: '10px 0px',
    }}>
    <Box style={{height:"64vh",width:"95%",marginLeft:"33px",marginTop:"10px"}}>
    <DataGrid
    onRowClick={handleRowClick}
    rows={biometricTable1}
    columns={columns}
    getRowId={(biometricTable1)=>biometricTable1.biometricReportId}
    initialState={{
       ...biometricTable1.initialState,
     pagination: { paginationModel: { pageSize: 8} },
   }}
   pageSizeOptions={[8,15,25,50,75]}

    >
       
    </DataGrid>
   </Box>
   </Box>
  );
}

