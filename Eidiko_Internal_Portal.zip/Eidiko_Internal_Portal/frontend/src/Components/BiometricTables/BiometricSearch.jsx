import { Autocomplete, Box, Button, Container, Divider, Grid, IconButton, TextField, Typography } from '@mui/material'
import React, { useCallback, useEffect, useState } from 'react'
import Loading from '../../Components/LoadingComponent/Loading'
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import { getAllEmployees } from '../../Services/employee-service/EmployeeService'
import { useLocation, useNavigate } from 'react-router';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import SearchIcon from '@mui/icons-material/Search';
import AutoEmpSearch from '../../Services/AutoEmpSearch/AutoEmpSearch';
import { taskService } from '../../Services/Employee-Task-Service/taskService';
import { toast } from 'react-toastify';
import BiometricTable from './BiometricTable';
import { BiometricServiceModule } from '../../Services/BiometricService/BiometricServiceModule';
import PreviewIcon from '@mui/icons-material/Preview';
import { DataGrid } from '@mui/x-data-grid';

const columns = [
  { 
    field: 'empId',
   headerName: 'Employee Id', 
   width: 125,
    flex:1.5,
   headerClassName:'table-header'
 
  },
  { 
    field: 'empName',
   headerName: 'Employee Name', 
   width: 200,
    flex:4,
   headerClassName:'table-header'

  },
  { 
    field: 'lateCount',
   headerName: 'Late Count',
   width: 125,
    flex:1.5,
   headerClassName:'table-header'
   
  },
  { 
    field: 'nonLateCount',
   headerName: 'Non Late',
   width: 125,
    flex:1.5,
   headerClassName:'table-header'
   
  },
  { 
    field: 'greaterThanWrkHrsCount',
   headerName: 'Greater Working Hour',
   width: 125,
    flex:1.5,
   headerClassName:'table-header'
   
  },
  {
  field: 'lessThanWrkHrsCount',
  headerName: 'Less Working Hour',
  width: 125,
   flex:1.5,
  headerClassName:'table-header'
  
 },
 {
  field: 'veryLateCount',
  headerName: 'Very Late',
  width: 125,
   flex:1.5,
  headerClassName:'table-header'
  
 },
 {
  field: 'avgworkingMinutes',
  headerName: 'Average Working Minute',
  width: 125,
   flex:1.5,
  headerClassName:'table-header'
  
 },

  {
    field: 'View',
    headerName: 'View',
    width: 140,
    flex:1.5,
    headerClassName: 'table-header',
    renderCell: (params) => {
      
      
      return (
        <Box sx={{
            display: 'flex',
            justifyContent: 'center'
        }}>
            <IconButton variant="contained" color='error'>
           <PreviewIcon  color='secondary' sx={{marginRight:"39px"}}/>
           </IconButton >

        </Box>
    );

    }
}
 
];





export const BiometricSearch = (props) => {

  const {state}=useLocation(props.state)

  const button1 = { backgroundColor: "#2196F3", color: "white", width: "150px",height:"50px",
  borderRadius: "10px",marginTop:"15px",marginRight:"42px" }
  const textfield1 = { width: 400 }
  const backbutton=useNavigate()
const[isLoading,setIsLoading]=useState(false)
const [employee, setEmployee] = useState({
  "fromDate":"2023-01-01",
  "toDate":dayjs().format("YYYY-MM-DD"),
  "empId": state
});
  
const [hidden,sethidden]=useState(false)

const navigate=useNavigate()
//--------------------fetching all employee biometric -------------------------------------------
const[biometricTableNonLate,setBiometricTableNonLate]=useState([])
const [bioMetricTableViaEmpIdFromDateTodate,setbioMetricTableViaEmpIdFromDateTodate]=useState()

function fetchNonLateData(){
  setIsLoading(true)
  BiometricServiceModule.getAllBiometricReportNonLate(employee.fromDate,employee.toDate).then((res)=>{
      if(res.status===200){
        setIsLoading(false)
      setBiometricTableNonLate(res.result)
      }
      else{
        setIsLoading(false)
        toast.error(res.message, {
          position: toast.POSITION.TOP_RIGHT
      })
      }
  
    }).catch((err)=>{
  
    setIsLoading(false)
    })
}

///////////////////////////////////////////////fetching data empid ,fromdate toDate///////////////////////////
function fetchViaParticularEmpIdData(){
  setIsLoading(true)
  BiometricServiceModule.getAllBiometricDataViaEmpIdStartDateEndDate(employee.empId,employee.fromDate,employee.toDate).then((res)=>{
 
      if(res.status===200){
        setIsLoading(false)
        setbioMetricTableViaEmpIdFromDateTodate(res.result)
      }
      else{
        setIsLoading(false)
        toast.error(res.message, {
          position: toast.POSITION.TOP_RIGHT
      })
      }
  
    }).catch((err)=>{
  
    setIsLoading(false)
    })
}

/////////////////////////////////// serching data via start date and end date is late ///////////////////////////////////////////////
function SearchIsLateData(){
  setIsLoading(true)
  BiometricServiceModule.getAllBiometricReportIsLate(employee.fromDate,employee.toDate).then((res)=>{

      if(res.status===200){
        setIsLoading(false)
        setBiometricTableNonLate(res.result)
      }
      else{
        setIsLoading(false)
        toast.error(res.message, {
          position: toast.POSITION.TOP_RIGHT
      })
      }
  
    }).catch((err)=>{
  
    setIsLoading(false)
    })
}


useEffect(()=>{ 
  
if(employee.empId !==null && employee.fromDate.length>0 && employee.toDate.length>0){
  
  fetchViaParticularEmpIdData(employee.empId,employee.fromDate,employee.toDate)
}
else if(employee.empId ==null && employee.fromDate.length>0 && employee.toDate.length>0){
  fetchNonLateData(employee.fromDate,employee.toDate)
}

sethidden(false)
},[employee.empId,hidden])


const handleSerchData=(e)=>{
    e.preventDefault()
 

  if(employee.fromDate.length>0 && employee.toDate.length>0  && employee.empId==null){
        
        SearchIsLateData(employee.fromDate,employee.toDate)
      
  }
   else if(employee.empId !==null && employee.fromDate.length>0 && employee.toDate.length>0){
    fetchViaParticularEmpIdData(employee.empId,employee.fromDate,employee.toDate)
   
   }

  else{
    toast.error("Please enter start date, end Date ", {
      position: toast.POSITION.TOP_RIGHT
  })
   
  }
  

   }
    
   const handleRowClick=(params)=>{
    setEmployee({...employee,empId:params.row.empId})

   }




    return (

isLoading?<Loading></Loading>:

        <Box sx={{
            height: 200,
            width: '75vw',
            padding: '10px 0px',
         
        }}>
             
                 <Box sx={{
                display: 'flex',
                alignContent: 'center',
                justifyContent: 'space-between',
                // marginTop:"10px",marginBottom:"20px"
                marginRight:"30px"
            }}>
             <Typography color={"secondary"} style={{marginLeft:"35px",fontSize:"26px"}}>BIOMETRIC DATA</Typography>

             <Grid style={{justifyContent:"center"}}>
                <Button variant='outlined' style={{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"4px",marginRight:"12px"}} 
                  onClick={()=>{sethidden(true);setbioMetricTableViaEmpIdFromDateTodate();  setEmployee({...employee,fromDate:"2023-01-01",toDate:dayjs().format("YYYY-MM-DD"),empId:null});backbutton(`../biometric-search`)}}
                 startIcon={<ArrowBackIosNewIcon/>}>
            back
                </Button>
                </Grid>

                 </Box>

                 
        <Box style={{marginLeft:"25px",width:"95%"}}>
            <Divider color='#2196F3' sx={{ margin: '1px 0px',height:"1px"}}  />
            </Box>
                
 {/*--------------InputFields:-----------FromDate---ToDate---EmpId-------------------------- */}



<form onSubmit={handleSerchData}> 
{/* <input type='hidden' value={hidden} onChange={(e)=>{sethidden("click")}}></input> */}
  <Box
   
    sx={{height:"100px",display:"flex",width:"75vw"}}
    >
      <Grid container  sx={{
            display: 'flex',
            justifyContent: 'space-between',
            width:"100vw",
            marginLeft:"20px",
            
           
      }}>
      <Grid item xs={3} sm={3} md={3} lg={3} xl={3} sx={{
            display: 'flex',
            justifyContent: 'center',
            marginTop:"9px",
            padding:"20px"
            
        
        }}style={textfield1} >

<TextField InputLabelProps={{ shrink: true }} 
 style={{width:"300px"}} type='date' 
 value={employee.fromDate}
  onChange={(e)=>{setEmployee({ ...employee,fromDate:e.target.value})}} 
  label="From Date"></TextField>
           
        </Grid >
        <Grid item xs={3} sm={3} md={3} lg={3} xl={3} sx={{
            display: 'flex',
            justifyContent: 'center',
            marginTop:"8px",
            padding:"20px"
            
        
        }} style={textfield1}>

<TextField InputLabelProps={{ shrink: true }}  style={{width:"300px"}} type='date' value={employee.toDate} 
onChange={(e)=>{setEmployee({ ...employee,toDate:e.target.value})}} label="To Date"></TextField>
            
        </Grid >


       
         <Grid item xs={3} sm={3} md={3}  lg={3} xl={3} sx={{
            display: 'flex',
            marginTop:"8px",
            justifyContent: 'center',
            padding:"20px"
        }}>
            <Button value="click" variant='outlined' type='submit'
             sx={{justifyContent:"center",display:"flex",width:"195px"}} endIcon={<SearchIcon/>}>
            search
                </Button>
                </Grid> 
                 
      </Grid>
      
      
      </Box>
      

      </form>

      <Box style={{marginLeft:"25px",marginRight:"33px",width:"95%",}}>
            <Divider color='#2196F3' sx={{ margin: '1px 0px',height:"1px"}}  />
            </Box>
{/*-----------------------Tabel:---------------------------- */} 
    

  
{bioMetricTableViaEmpIdFromDateTodate==null  ? 

  <Box sx={{
        height: 200,
        width: '75vw',
        padding: '10px 0px',
    }}>
    <Box style={{height:"64vh",width:"95%",marginLeft:"33px",marginTop:"10px"}}>
    <DataGrid
    rows={biometricTableNonLate}
    columns={columns}
    getRowId={(biometricTableNonLate)=>biometricTableNonLate.empId}
    initialState={{
       ...biometricTableNonLate.initialState,
     pagination: { paginationModel: { pageSize: 8} },
   }}
   pageSizeOptions={[8,15,25,50,75]}
onRowClick={handleRowClick}
    >
       
    </DataGrid>
   </Box>
   </Box>
   :<BiometricTable biometricdata={bioMetricTableViaEmpIdFromDateTodate} />
      
  }


        </Box>
    )
}

 