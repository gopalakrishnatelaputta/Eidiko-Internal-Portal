import * as React from 'react';
// import './em.css'
import { 
  Box,
  Grid, 
   Paper,
   Typography,
        } from "@mui/material";
import {FcBusinessman} from "react-icons/fc";
import { DataGrid } from '@mui/x-data-grid';
import { Button } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { Navigate, useLocation, useNavigate } from 'react-router';
import {Divider} from '@mui/material';
import {Container} from '@mui/material';
import Person4Icon from '@mui/icons-material/Person4';
import {IconButton} from '@mui/material';
import { Delete } from '@mui/icons-material';
import { getReportingManagerTable } from '../../Services/employee-service/EmployeeService';
import { toast } from 'react-toastify'
import Loading from "../../Components/LoadingComponent/Loading";
import { useState } from 'react';
import moment from 'moment';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import { helpFunction } from '../HelperComponent/helpFunction';
import Brightness1Icon from '@mui/icons-material/Brightness1';
import PreviewIcon from '@mui/icons-material/Preview';
import dayjs from 'dayjs';
import { BiometricServiceModule } from '../../Services/BiometricService/BiometricServiceModule';
import SearchIcon from '@mui/icons-material/Search';
import {TextField} from '@mui/material';
const columns = [
    { 
        field: 'empId',
       headerName: 'Employee Id', 
       width: 125,
        flex:2,
       headerClassName:'table-header'
     
      },  
 
  { 
    field: 'Biometric date',
   headerName: 'Biometric Date', 
   width: 125,
    flex:2,
    headerClassName:'table-header',
    valueGetter: getDate,
  },
  { 
    field: 'Biometric Time',
   headerName: 'Biometric Time', 
   width: 125,
    flex:2,
    headerClassName:'table-header',
    valueGetter: getTime,
  },  
 

];

function getDate(params) {
  return moment(params.row?.bioDate).format("DD/MM/YYYY")
}
function getTime(params) {
  return moment(params.row?.bioDate).format("HH:mm:ss")
}

export default function BiometricTableAterClickingView(props) {

const {state}=useLocation(props.state)
const data=state
const[isLoading,setIsLoading]=useState(false)
const textfield1 = { width: 400 }
const [employee, setEmployee] = useState({
    "fromDate":"2023-01-01",
    "toDate":dayjs().format("YYYY-MM-DD"),
    "empId":data
  });
  const[empId1,setEmpId1]=useState()
  const [biometricTable1,setBiometricTable1]=React.useState([])
  function fetchDataAfterclickingView(){
    setIsLoading(true)
    BiometricServiceModule.getAllBiometricReportAfterClickingView(employee.empId,employee.fromDate,employee.toDate).then((res)=>{
        if(res.status===200){
          setIsLoading(false)
          setBiometricTable1(res.result)
           setEmpId1(employee.empId)
        }
        else{
          setIsLoading(false)
          toast.error(res.message, {
            position: toast.POSITION.TOP_RIGHT
        })
        }
    
      }).catch((err)=>{
    
      setIsLoading(false)
      })
  }
  
  React.useEffect(()=>{
fetchDataAfterclickingView()
  },[employee.empId])


const handleSerchData=(e)=>{
 if(employee.empId!==null && employee.fromDate.length>0 && employee.toDate.length>0){
 fetchDataAfterclickingView(employee.empId,employee.fromDate,employee.toDate)
 }

 else{
    toast.info("Please Enter a start date ,end date", {
        position: toast.POSITION.TOP_RIGHT
    })
 }
}

const backbutton=useNavigate()


  return (
isLoading?<Loading></Loading>:
    <Box sx={{
        height: 200,
        width: '75vw',
        padding: '10px 0px',
     
    }}>
         
             <Box sx={{
            display: 'flex',
            alignContent: 'center',
            justifyContent: 'space-between',
            // marginTop:"10px",marginBottom:"20px"
            marginRight:"30px"
        }}>
         <Typography color={"secondary"} style={{marginLeft:"35px",fontSize:"26px"}}>BIOMETRIC DETAILS</Typography>

         <Grid style={{justifyContent:"center"}}>
            <Button variant='outlined' style={{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"4px",marginRight:"12px"}} 
               onClick={()=>{ setEmployee({...employee,fromDate:"2023-01-01",toDate:dayjs().format("YYYY-MM-DD")});backbutton(`../biometric-search`,{state:empId1})}}
             startIcon={<ArrowBackIosNewIcon/>}>
           back
            </Button>
            </Grid>

             </Box>

             
    <Box style={{marginLeft:"25px",width:"95%"}}>
        <Divider color='#2196F3' sx={{ margin: '1px 0px',height:"1px"}}  />
        </Box>
            
{/*--------------InputFields:-----------FromDate---ToDate---EmpId-------------------------- */}



<form onSubmit={handleSerchData}> 
{/* <input type='hidden' value={hidden} onChange={(e)=>{sethidden("click")}}></input> */}
<Box

sx={{height:"100px",display:"flex",width:"75vw"}}
>
  <Grid container  sx={{
        display: 'flex',
        justifyContent: 'space-between',
        width:"100vw",
        marginLeft:"20px",
        
       
  }}>
  <Grid item xs={3} sm={3} md={3} lg={3} xl={3} sx={{
        display: 'flex',
        justifyContent: 'center',
        marginTop:"9px",
        padding:"20px"
        
    
    }}style={textfield1} >

<TextField InputLabelProps={{ shrink: true }} 
style={{width:"300px"}} type='date' 
value={employee.fromDate}
onChange={(e)=>{setEmployee({ ...employee,fromDate:e.target.value})}} 
label="From Date"></TextField>
       
    </Grid >
    <Grid item xs={3} sm={3} md={3} lg={3} xl={3} sx={{
        display: 'flex',
        justifyContent: 'center',
        marginTop:"8px",
        padding:"20px"
        
    
    }} style={textfield1}>

<TextField InputLabelProps={{ shrink: true }}  style={{width:"300px"}} type='date' value={employee.toDate} 
onChange={(e)=>{setEmployee({ ...employee,toDate:e.target.value})}} label="To Date"></TextField>
        
    </Grid >


   
     <Grid item xs={3} sm={3} md={3}  lg={3} xl={3} sx={{
        display: 'flex',
        marginTop:"8px",
        justifyContent: 'center',
        padding:"20px"
    }}>
        <Button value="click" variant='outlined' type='submit'
         sx={{justifyContent:"center",display:"flex",width:"195px"}} endIcon={<SearchIcon/>}>
        search
            </Button>
            </Grid> 
             
  </Grid>
  
  
  </Box>
  

  </form>

  <Box style={{marginLeft:"25px",marginRight:"33px",width:"95%",}}>
        <Divider color='#2196F3' sx={{ margin: '1px 0px',height:"1px"}}  />
        </Box>







    <Box sx={{
        height: 200,
        width: '75vw',
        padding: '10px 0px',
    }}>
    <Box style={{height:"64vh",width:"95%",marginLeft:"33px",marginTop:"10px"}}>
    <DataGrid
    rows={biometricTable1}
    columns={columns}
    getRowId={(biometricTable1)=>biometricTable1.biometricId}
    initialState={{
       ...biometricTable1.initialState,
     pagination: { paginationModel: { pageSize: 8} },
   }}
   pageSizeOptions={[8,15,25,50,75]}

    >
       
    </DataGrid>
   </Box>
   </Box>
   </Box>
  );
}

