import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';
import MenuItem from '@mui/material/MenuItem';
import AdbIcon from '@mui/icons-material/Adb';
import { Link, useNavigate } from 'react-router-dom';
import { GlobalButton } from '../stylecomponent/GlobalButton';

//logout

import LogoutIcon from '@mui/icons-material/Logout';
import Stack from '@mui/material/Stack';
import Swal from 'sweetalert2';
import { ListItemButton, ListItemIcon, ListItemText, Modal } from '@mui/material';
import SideNavBar from './SideNavBar';
import userServiceModule from '../../Services/user-service/UserService';

//socialButton
import BottomNavigation from '@mui/material/BottomNavigation';
import BottomNavigationAction from '@mui/material/BottomNavigationAction';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import GoogleIcon from '@mui/icons-material/Google';
import EmailRoundedIcon from '@mui/icons-material/EmailRounded';


//const pages=['Home','Service','About'];

function ResponsiveAppBar() {
  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  //LogOut
  const navigate = useNavigate()
  const logoutHandle = () => {
    Swal.fire({
      icon: "warning",
      iconColor:"#d50000",
      title: 'Do you want to Leave?',
      showCancelButton: true,
      confirmButtonColor: '#2196F3',
      cancelButtonColor: '#d50000'
    }).then((result) => {
      if (result.isConfirmed) {
        sessionStorage.clear()
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Logout successfully completed ! Redirecting to Login page...',
          showConfirmButton: false,
          timer: 1500
        })
        navigate("/login")
      } 
    })
   
   }

  
  const navigate1=useNavigate()

//socialButtons
const [value, setValue] = React.useState('recents');

const handleChange = (event, newValue) => {
  setValue(newValue);
};
//

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          
         {userServiceModule.isLogedin ? <Typography
            variant="h6"
            noWrap
            component="a"
            href="#"
            sx={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: '#FFFFFF',
              textDecoration: 'none',
            }}
          >
            EIDIKO
          </Typography>: <Typography
            variant="h6"
            noWrap
            component="a"
            href="/"
            sx={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: '#FFFFFF',
              textDecoration: 'none',
            }}
          >
            EIDIKO
          </Typography>}

          <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              // onClick={handleNavOpen}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            {/* <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              // onClose={handleNavClose}
              sx={{
                display: { xs: 'block', md: 'none' },
              }}
            >
              {pages.map((page) => (
                <MenuItem key={page} onClick={handleCloseNavMenu}>
                  <Typography textAlign="center">{page}</Typography>
                </MenuItem>
              ))}

               
            </Menu> */}
          </Box>
          <Typography
            variant="h5"
            noWrap
            component="a"
            href=""
            sx={{
              mr: 2,
              display: { xs: 'flex', md: 'none' },
              flexGrow: 1,
              fontFamily: 'monospace',
              fontWeight: 700,
              letterSpacing: '.3rem',
              color: '#FFFFFF',
              textDecoration: 'none',
            }}
          >
            EIDIKO
          </Typography>
          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {/* {pages.map((page) => (
              <Button
                key={page}
                onClick={handleCloseNavMenu}
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                {page}
              </Button>
            ))} */}
   
           
          </Box>
        
          <Stack  direction="row" spacing={2}>
         {userServiceModule.isLogedin() &&  <Button sx={{borderRadius:"40px"}} type='submit' 
          variant="contained"
          endIcon={<LogoutIcon />} onClick={logoutHandle} >
            Logout
          </Button>
         }
         
          {
            !userServiceModule.isLogedin() && <Button sx={{borderRadius:"40px"}} onClick={()=>{navigate1("/login")}} type='submit'
            variant="contained"
            endIcon={<LogoutIcon />} >
              Login
            </Button>
          }
         </Stack>

        </Toolbar>
      </Container>
    </AppBar>
  );
}
export default ResponsiveAppBar;