import {Button, Card, CardContent,TextField,Grid,Box, Typography } from '@mui/material';
import React, { useState } from 'react';
// import { GlobalButton } from '../../../Components/stylecomponent/GlobalButton';
import ContactPhoneIcon from '@mui/icons-material/ContactPhone';
// import { EmployeeAccessLevelService } from '../../../Services/Employee-Access-Level-service/EmployeeAccessService';
import { toast } from "react-toastify";
import Loading from '../LoadingComponent/Loading';
// import Loading from '../../../Components/LoadingComponent/Loading';
import userServiceModule from '../../Services/user-service/UserService';
import { GlobalButton } from '../stylecomponent/GlobalButton';



export const ProfileContactModal= (props) => {
   
    const[contact,setContact]=useState(props.contact)
    const[isLoading,setIsLoading]=useState(false)
const[empId,setEmpId]=useState(props.empId)
let func1=props.onClose

    const handleContact=(e)=>{
        setIsLoading(true)
        userServiceModule.updateContact(contact,empId).then((res)=>{
           // console.log(res)
    if(res.status===200 && res.statusMessage==='success' )
    {
         setIsLoading(false)
         toast.success(res.message, {
             position: toast.POSITION.TOP_CENTER
           });
           func1()
    }
    else{
        setIsLoading(false)
        toast.error(res.message, {
            position: toast.POSITION.TOP_CENTER
        });
        func1()
    }

    
    }).catch((error)=>{
        console.log(error);
        setIsLoading(false)
        toast.error(error.message, {
            position: toast.POSITION.TOP_CENTER
        });
        func1()
    })
}
 
    return (
        isLoading?<Loading/>:
     
            <Card style={{ maxWidth: 400, padding: "13px 5px", margin: "0 auto" ,marginTop:"150px"}}>
                                        <CardContent>


                      

                                            <center>
                                                <Typography style={{fontSize:"25px"}} color="primary">UPDATE CONTACT</Typography>
                                                <GlobalButton.GlobalDivider/>
                                            
                                             <form onSubmit={handleContact}>
                                                <Grid container spacing={1} >
                                                    <Grid item xs={12} sx={{justifyContent:"center",display:"flex"}}>
                                                    <TextField InputProps={{ inputProps: { min: 1111111111, max: 9999999999 } }} value={contact} onChange={(e)=>{setContact(e.target.value)}} type="number" label="Update Contact" required placeholder="update contact" variant='outlined'  style={{width:"550px",marginTop:"15px"}}></TextField>
                                                    </Grid>

                                                    <Grid item xs={12} sx={{display:'flex',
                                                    justifyContent:'center',
                                                    alignItems:'center'
                                                }}>
                                                        <Button   sx={{marginTop:"10px"}} type='submit' disableElevation variant="contained"
                                                         style={GlobalButton.OperationButton}>UPDATE</Button>

                                                        <Button  sx={{marginLeft:"20px",marginTop:"10px"}} onClick={props.onClose} variant='contained' 
                                                         style={GlobalButton.HaltButton}>Cancel</Button>
                                                    </Grid>
                                                    
                                                  
                                                </Grid>
                                                </form>
                                                <GlobalButton.GlobalDivider/>
                                            </center>
                                        </CardContent>
            </Card>

    )
}
