
import { Grid, Paper , TextField, Button, Input,Box,Link,Typography,Container, Divider} from "@mui/material";
import FingerprintIcon from '@mui/icons-material/Fingerprint';

import InventoryIcon from '@mui/icons-material/Inventory';
import { Dropzone } from "@mantine/dropzone";
import Swarm from "../../images/Swarm.png"
import { useState } from "react";
import { BiometricServiceModule } from "../../Services/BiometricService/BiometricServiceModule";
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import { useNavigate } from "react-router";
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import { useDropzone } from "react-dropzone";
import InsertDriveFileOutlinedIcon from '@mui/icons-material/InsertDriveFileOutlined';
import axios from "axios";
import { toast } from "react-toastify";
import ClearOutlinedIcon from '@mui/icons-material/ClearOutlined';
import Loading from "../../Components/LoadingComponent/Loading";
import upload from "../../images/upl.png"
import { baseUrl } from "../../Server/baseUrl";

export default function DataUpload(){
    const button1={backgroundColor:"#2196F3",color:"white",borderRadius:"20px",marginBottom:"20px",width:"22%"}
    const textfield1={width: 400,height:100}
const[biometric,setBiometric]=useState([])


const fileHandler=(file)=>{
  setBiometric(file[0])
}
const token = sessionStorage.getItem("token")
let form =new FormData()
form.append("file",biometric)

const[isloading,setisloading]=useState(false)

const fileDataSubmit=(e)=>{
    e.preventDefault()
   setisloading(true)
axios({
    method: "post",
    url: `${baseUrl}/biometric/add-file`,
    data:form,
    headers: { "Content-Type": 'multipart/form-data' ,"Authorization" : 'Bearer ' + token},
  }).then((res)=>{
 if(res.status===200 && res.data.status==="Success"){
    setisloading(false)
    toast.success(res.data.message,{position:toast.POSITION.TOP_RIGHT})
    setBiometric("");
}
else if( res.status===200 && res.data.status===400){
    setisloading(false)
    toast.info(res.data.message,{position:toast.POSITION.TOP_RIGHT})

}
else{
    setisloading(false)
    toast.error(res.data.message,{position:toast.POSITION.TOP_RIGHT})
}

}).catch((error)=>{
    setisloading(false)
    toast.error(error.response.data.message,{position:toast.POSITION.TOP_RIGHT})
})

}


  //backbutton
  const backbutton=useNavigate()



  const handleUpdateClick = ()=>{
    setisloading(true);
    BiometricServiceModule.updateIsLateReport().then(
        res=>{
           if(res.status === 200){
            setisloading(false)
            toast.success(res.message,{position:toast.POSITION.TOP_RIGHT})
           }
        }
    ).catch(
        
        error=>{
            setisloading(false)
            alert("not updated");}
    )

  }

return(
    isloading?<Loading></Loading>:
    <Box style={{backgroundColor:"#FFFFFF",height:"92vh"}}>
        <form onSubmit={fileDataSubmit} method="post" enctype="multipart/form-data">

    
    <Box sx={{
           display: 'flex',
           alignContent: 'center',
           justifyContent: 'space-between',
           alignContent:"center",
           marginRight:"30px",
           
       }}>
        <Typography color={"secondary"}style={{marginLeft:"34px",fontSize:"26px"}}>BIO-METRIC</Typography>
           {/* <Grid style={{justifyContent:"center"}}>
           <Button variant='outlined' style={{fontWeight:"bold",color:"#2196F3",marginBottom:"3px",marginTop:"4px",marginRight:"12px"}} 
            onClick={()=>{backbutton("#")}}
            startIcon={<ArrowBackIosNewIcon/>}>
       back
           </Button>
           </Grid> */}
       </Box>


    <Divider color='#2196F3' sx={{ margin: '1px 0px',height:"1px"}}  />
    
    
    <section className="dropbox">

    <Container style={{padding:"20px",marginTop:10}} className="container">
        <Paper elevation={0} style={{width:"auto"}} >
        
        
        <Box sx={{ flexFlow: 1 }}>
            <Grid container spacing={1} gap={3}  justifyContent={"center"}
             alignItems={"center"} alignContent={"center"}>

                <Grid item xs={12} sx={{display:'flex',
                justifyContent:'center',
                alignItems:'center'
            }}>


   <Dropzone id="file-upload" maxFiles={3} multiple={true} loading={false} value={biometric}  onDrop={fileHandler} 
   ssx={{height:"25vh",width:"30vw",border:"3px solid #2196F3",backgroundColor:"#4fc3f7",display:"flex",}}>
       
       <Grid container style={{height:"26vh",width:"32vw",}} >
      

        <Grid item xs={12} sx={{justifyContent:"center",alignContent:"center",alignItems:"center"}}>
        <Typography align="center"> Drag  or click here to select files</Typography>
        
        </Grid>

      <Grid item xs={12} sx={{ display:"flex",justifyContent:"center",alignContent:"center",alignItems:"center"}}>
            {/* <InventoryIcon  sx={{borderRadius:"50%",fontSize:"90px"}}></InventoryIcon> */}
            <img style={{width:"150px",height:"120px"}}src={upload}></img>
            {/* 'https://www.pngall.com/wp-content/uploads/2/Upload-PNG-Image-File.png' */}
        </Grid>
<Grid item xs={12} sx={{display:"flex",justifyContent:"center",alignContent:"center",alignItems:"center"}}>
{/* <Input disabled id="uploadFile"></Input> */}<Button variant="outlined">Select File <InsertDriveFileOutlinedIcon style={{fontSize:"16px"}}/></Button>
</Grid>


          
      </Grid>   
       </Dropzone>

                </Grid>

<Grid item xs={12} sx={{display:'flex',
                    justifyContent:'center',
                    alignItems:'center'
                }}>

                        <Button type="submit" sx={{marginBottom:"10px"}}  variant='contained'  >Upload <FileUploadOutlinedIcon/></Button>
                    </Grid>
            

            </Grid>
        </Box>
        {/* </form> */}
        </Paper>
    </Container>
    </section>
   { biometric.length===0 ? null: <Grid item xs={12} sx={{display:"flex",justifyContent:"center",alignContent:"center",alignItems:"center",marginLeft:"55px",marginTop:"15px"}}>
    <Input disabled  id="uploadFile" value={biometric?.path}></Input>
<Button onClick={(e)=>{setBiometric([])}} type="reset"><ClearOutlinedIcon  style={{color:"red"}}/></Button>
</Grid>}
<Divider color='#2196F3' sx={{ margin: '1px 0px',height:"1px",marginTop:"55px"}}  />

</form>


<Box>
        <Button onClick={handleUpdateClick} variant='contained'>Update Biometric Report</Button>
        </Box>    
</Box>


   


    )

}