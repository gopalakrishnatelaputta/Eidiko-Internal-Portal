import { Box, Button, Card, FormControlLabel, FormGroup, Paper } from '@mui/material';
import React, { useState } from 'react'
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import { DataGrid } from '@mui/x-data-grid';
import { taskService } from '../../Services/Employee-Task-Service/taskService';
import { useEffect } from 'react';
import { toast } from 'react-toastify';
import moment from 'moment';
import {Modal} from '@mui/material';
import TaskDetailsElaborately from '../../Components/TaskComponent/TaskDetailsElaborately';
import PreviewIcon from '@mui/icons-material/Preview';
import {IconButton} from '@mui/material';
import { useNavigate } from 'react-router';

  

  
export const VerificationTable = (props) => {
  const navigate=useNavigate
  const [reportm,setReportm]=useState(false)
    const handleRmOpen=()=>{
      setReportm(true)
    }
 
let data=props.allTask
const [VerificationTable,setVerificationTable]=useState([])
const [rowSelectionModel, setRowSelectionModel] = React.useState([]);

const verificationHandle=()=>{
  taskService.VerificationOfDaylyReport(rowSelectionModel).then((res)=>{
    if(res.status===200 && res.statusMessage==='Success' ){

        toast.success(res.message, {
            position: toast.POSITION.TOP_CENTER
          });
          window.location.reload()
      }
      else{
        toast.error(res.message, {
            position: toast.POSITION.TOP_CENTER
        });

      }
}).catch((error)=>{
    toast.error(error.message, {
        position: toast.POSITION.TOP_CENTER
    });
})
setRowSelectionModel([])

}

  useEffect(()=>{setVerificationTable(data)},[data])

  

const [data1,setData1]=useState()

  
  const handleRowClick = (params) => {
       setData1(params.row)
    };

    const columns = [ 
      // { 
      //   field: 'taskDetailsId',
      //  headerName: 'Task Details Id', 
      //  width: 125,
      //   flex:1.5,
      //  headerClassName:'table-header'
     
      // },
      { 
        field: 'empId',
       headerName: 'Employee Id', 
       width: 125,
        flex:1.5,
       headerClassName:'table-header'
     
      },
      // { 
      //   field: 'taskDetail',
      //  headerName: 'Task Details',
      //  width: 210,
      //   flex:2,
      //  headerClassName:'table-header'
       
      // },
      // { 
      //   field: 'desc',
      //  headerName: 'Description',
      //  width: 210,
      //   flex:2,
      //  headerClassName:'table-header'
       
      // },
      { 
        field: 'status',
       headerName: 'Status', 
       width: 125,
        flex:2,
       headerClassName:'table-header'
       ,renderCell: (params) => {
        if (params.row.status==="Yes"){
          return "Completed"
        }
        return "Not Completed"
    
       }
    
    
      },
      { 
        field: 'reason',
       headerName: 'Reason', 
       width: 210,
        flex:1.5,
       headerClassName:'table-header'
    
      },
      { 
          field: 'assignedDate',
         headerName: 'Assigned Date', 
         width: 125,
          flex:2,
         headerClassName:'table-header',
         valueFormatter: params => 
         moment(params?.value).format("DD/MM/YYYY"),  
        },
      { 
          field: 'statusReportDate',
         headerName: 'Status Reporting Date', 
         width: 125,
          flex:2,
         headerClassName:'table-header',
         valueFormatter: params => 
       moment(params?.value).format("DD/MM/YYYY"),  
        },
     
        { 
          field: 'team',
         headerName: 'Team', 
         width: 125,
          flex:2,
         headerClassName:'table-header'
         
        },
        { 
          field: 'assignedByName',
         headerName: 'AssignedBy', 
         width: 140,
          flex:3,
         headerClassName:'table-header'
         
        },
      
      {
        field: 'View',
        headerName: 'View',
        width: 140,
        flex:2,
        headerClassName: 'table-header',
        renderCell: (params) => {
          
          
          return (
            <Box sx={{
                display: 'flex',
                justifyContent: 'center'
            }}>
                <IconButton variant="contained" color='error'>
               <PreviewIcon onClick={handleRmOpen} color='secondary' sx={{marginRight:"39px"}}/>
                <Modal
                sx={{overflow:"scroll"}}
                    open={reportm}
                    aria-labelledby="parent-modal-title"
                    aria-describedby="parent-modal-description">
                  <center><Paper elevation={0} sx={{width:800,justifyContent:"center"}}>
                    <TaskDetailsElaborately row1={rowSelectionModel} state={data1} onClose1={()=>{setReportm(false)}} />
                  </Paper></center>
                </Modal>
               </IconButton >
    
            </Box>
        );
    
    
    
    
        }
    }
    ];






    return (
        <Box sx={{
            height: 200,
            width: '75vw',
            padding: '10px 0px',
        }}>
        <Box style={{height:"64vh",width:"95%",marginLeft:"33px",marginTop:"10px"}}>
        <DataGrid

 checkboxSelection
 onRowSelectionModelChange={(newRowSelectionModel) => {
  setRowSelectionModel(newRowSelectionModel);
}}
rowSelectionModel={rowSelectionModel}
        onRowClick={handleRowClick}
        rows={VerificationTable}
        columns={columns}
        getRowId={(VerificationTable)=>VerificationTable.taskDetailsId}
        initialState={{
           ...VerificationTable.initialState,
         pagination: { paginationModel: { pageSize: 8} },
       }}
       pageSizeOptions={[8,15,25,50,75]}

        >
           
        </DataGrid>
        <Box sx={{display:"flex",justifyContent:"center",mt:2}}>
        {rowSelectionModel.length>0?<Button variant='contained' sx={{width:"150px",borderRadius:"20px"}} type='submit' onClick={verificationHandle}>verify</Button>:null}
        </Box>


       </Box>







       </Box>
    )
}




/////////////////searched table/////////////////////////
