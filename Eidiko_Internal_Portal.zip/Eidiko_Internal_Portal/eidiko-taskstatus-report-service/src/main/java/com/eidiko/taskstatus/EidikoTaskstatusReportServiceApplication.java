package com.eidiko.taskstatus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EidikoTaskstatusReportServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EidikoTaskstatusReportServiceApplication.class, args);


	}

}
