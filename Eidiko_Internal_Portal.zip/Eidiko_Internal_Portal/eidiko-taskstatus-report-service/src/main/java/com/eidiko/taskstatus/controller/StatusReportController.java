package com.eidiko.taskstatus.controller;

import com.eidiko.taskstatus.dto.DailyStatusReportDto;
import com.eidiko.taskstatus.dto.DailyStatusReportResponseDto;
import com.eidiko.taskstatus.dto.VerificationReqDto;
import com.eidiko.taskstatus.exception.NotNullException;
import com.eidiko.taskstatus.exception.ReportAlreadyExistsException;
import com.eidiko.taskstatus.helper.ConstantValues;
import com.eidiko.taskstatus.repository.EmployeeRepository;
import com.eidiko.taskstatus.service.ServiceClass;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/V1/dailyStatusReport")
public class StatusReportController {

    Map<String, Object> map = new HashMap<>();
    @Autowired
    private ServiceClass serviceClass;

    Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
    private EmployeeRepository employeeRepository;



    @PostMapping("/add/{empId}")
    @Operation(summary = "To Insert DailyStatusReport Details" ,
            description = "To Insert DailyStatusReport Details",tags = "POST")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> add(@Valid @RequestBody DailyStatusReportDto dailyStatusReportDto, @PathVariable("empId") long empId) throws ReportAlreadyExistsException, NotNullException {
        this.serviceClass.add(dailyStatusReportDto,empId);

        map.put(ConstantValues.MESSAGE , ConstantValues.CREATED);
        map.put(ConstantValues.STATUS_TEXT , HttpStatus.CREATED.value());
        map.put(ConstantValues.STATUS_CODE, ConstantValues.STATUS_MESSAGE);
        logger.info(ConstantValues.RESULT + ResponseEntity.ok(map) );
        return ResponseEntity.ok(map);
    }

    @GetMapping("/get")
    @Operation(summary = "Get All Reports" ,
            description = "To get All DailyStatusReports",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> getAll(@RequestParam(defaultValue = "0") Integer pageNo,
                                                      @RequestParam(defaultValue = "5") Integer pageSize,
                                                      @RequestParam(defaultValue = "taskDetailsId") String sortBy) {
        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
        ResponseEntity<Map<String, Object>> list;
        list = this.serviceClass.getAll(paging);
        return list;
    }
    @GetMapping("/get/{empId}")
    @Operation(summary = "Get All Reports  by EmployeeId" ,
            description = "To get All  Reports  by EmployeeId",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> list(@PathVariable("empId")long empId,
                                                    @RequestParam(defaultValue = "0") Integer pageNo,
                                                    @RequestParam(defaultValue = "5") Integer pageSize,
                                                    @RequestParam(defaultValue = "taskDetailsId") String sortBy) {
        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
        ResponseEntity<Map<String, Object>> dailyStatusReports;
        dailyStatusReports = this.serviceClass.getByEmpId(empId,paging);
        return dailyStatusReports;
    }


    @PutMapping("updateAll")
    @Operation(summary = "Update All Records By verifiedBy ID" ,
            description = "Update All Records By verifiedBy ID",tags = "PUT")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String,Object>>updateAllDailyStatus(@RequestBody VerificationReqDto verificationReqDto){

        this.serviceClass.updateAllDailyStatus(verificationReqDto.getTaskDetailsId(), verificationReqDto.getVerifiedById());
        map.put(ConstantValues.MESSAGE, ConstantValues.UPDATED);
        map.put(ConstantValues.STATUS_TEXT , HttpStatus.OK.value());
        map.put(ConstantValues.STATUS_CODE, ConstantValues.STATUS_MESSAGE);
        return ResponseEntity.ok(map);
    }
    @GetMapping("/get/{fromDate}/{toDate}")
    @Operation(summary = "Get All Reports between dates" ,
            description = "To get All  Reports between dates",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> findByDate(@PathVariable("fromDate")  @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localFromDate,
                                                          @PathVariable("toDate")  @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localToDate,
                                                          @RequestParam(defaultValue = "0") Integer pageNo,
                                                          @RequestParam(defaultValue = "5") Integer pageSize,
                                                           @RequestParam(defaultValue = "taskDetailsId") String sortBy) {
        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
        Timestamp fromDate = Timestamp.valueOf(localFromDate.atStartOfDay());
        Timestamp toDate = Timestamp.valueOf(localToDate.atStartOfDay());

        return this.serviceClass.findByDate(fromDate,toDate,paging);

    }

    @GetMapping("/getPending/{fromDate}/{toDate}")
    @Operation(summary = "Get All verifiedBy pending reports between dates" ,
            description = "To get All verifiedBy pending reports between dates",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> pendingReportsBetweenDates(@PathVariable("fromDate")  @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localFromDate,
                                                              @PathVariable("toDate")  @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localToDate) {
        Timestamp fromDate = Timestamp.valueOf(localFromDate.atStartOfDay());
        Timestamp toDate = Timestamp.valueOf(localToDate.atStartOfDay());

        ResponseEntity<Map<String, Object>> list;
        list = this.serviceClass.pendingReportsBetweenDates(fromDate,toDate);
        return list;
    }

    @GetMapping("/getAllPendingReports")
    @Operation(summary = "Get All verifiedBy pending reports" ,
            description = "To get All verifiedBy pending reports",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> pendingReports() {

        ResponseEntity<Map<String, Object>> list;
        list = this.serviceClass.pendingReports();
        return list;
    }

    @GetMapping("/getStatus/{fromDate}/{toDate}")
    @Operation(summary = "Get All pending status reports between dates" ,
            description = "To get All  pending status reports between dates",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> pendingStatusBetweenDates(@PathVariable("fromDate")  @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localFromDate,
                                                             @PathVariable("toDate")  @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localToDate,
                                                             @RequestParam("status") String status ,
                                                             @RequestParam(defaultValue = "0") Integer pageNo,
                                                             @RequestParam(defaultValue = "5") Integer pageSize,
                                                             @RequestParam(defaultValue = "taskDetailsId") String sortBy) {
        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
        Timestamp fromDate = Timestamp.valueOf(localFromDate.atStartOfDay());
        Timestamp toDate = Timestamp.valueOf(localToDate.atStartOfDay());

        ResponseEntity<Map<String, Object>> list;
        list = this.serviceClass.pendingStatusBetweenDates(fromDate,toDate,status,paging);
        return list;

    }

    @GetMapping("/getAllPendingStatus")
    @Operation(summary = "Get All pending status reports" ,
            description = "To get All pending status report",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> pendingStatus(@RequestParam("status") String status ,
                                                             @RequestParam(defaultValue = "0") Integer pageNo,
                                                             @RequestParam(defaultValue = "5") Integer pageSize,
                                                             @RequestParam(defaultValue = "taskDetailsId") String sortBy) {
        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

        ResponseEntity<Map<String, Object>> list;
        list = this.serviceClass.pendingStatus(status,paging);
        return list;

    }


    @GetMapping("/get/{empId}/{startDate}/{endDate}")
    @Operation(summary = "Get All Reports  by EmployeeId between dates" ,
            description = "To get All  Reports  by EmployeeId  between dates",tags = "Get")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200",description = "Data Fetched Successfully",
                    content = {@Content(mediaType = "application/json",schema = @Schema(implementation = DailyStatusReportResponseDto.class))})})
    public ResponseEntity<Map<String, Object>> getDailyStatusReportsForEmployeeBetweenDates(
            @PathVariable("empId") Long empId,
            @PathVariable("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localStartDate,
            @PathVariable("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate localEndDate,
            @RequestParam(defaultValue = "0") Integer pageNo,
            @RequestParam(defaultValue = "5") Integer pageSize,
            @RequestParam(defaultValue = "taskDetailsId") String sortBy) {
        Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
        Timestamp startDate = Timestamp.valueOf(localStartDate.atStartOfDay());
        Timestamp endDate = Timestamp.valueOf(localEndDate.atStartOfDay());

        ResponseEntity<Map<String, Object>> list;
        list = this.serviceClass.getDailyStatusReportsForEmployeeBetweenDates(empId,startDate,endDate,paging);

        return  list;

    }


}
