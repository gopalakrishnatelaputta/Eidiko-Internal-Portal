/*
package com.eidiko.taskstatus.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class HolidayList {

    @Id
    private long holidayListId;
    private LocalDate holidayDate;
    private String holidayDesc;
    private int holidayYear;
}
*/
