package com.eidiko.taskstatus.exception;

public class NotNullException extends Throwable {
    public NotNullException(String message) {
        super(message);
    }
}
