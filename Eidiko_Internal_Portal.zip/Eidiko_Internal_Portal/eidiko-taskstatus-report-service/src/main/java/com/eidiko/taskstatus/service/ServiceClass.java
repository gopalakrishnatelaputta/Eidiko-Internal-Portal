package com.eidiko.taskstatus.service;

import com.eidiko.taskstatus.dto.DailyStatusReportDto;
import com.eidiko.taskstatus.exception.NotNullException;
import com.eidiko.taskstatus.exception.ReportAlreadyExistsException;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public interface ServiceClass {
    void add(DailyStatusReportDto dailyStatusReportDto, long empId) throws ReportAlreadyExistsException, NotNullException;
    void updateAllDailyStatus(List<Long> taskDetailsId, long verifiedById);
    ResponseEntity<Map<String, Object>> getByEmpId(long empId, Pageable pageable);
    ResponseEntity<Map<String,Object>> getAll(Pageable pageable);
    ResponseEntity<Map<String, Object>> findByDate(Timestamp fromDate, Timestamp toDate, Pageable pageable);
    ResponseEntity<Map<String, Object>> pendingReportsBetweenDates(Timestamp fromDate, Timestamp toDate);
    ResponseEntity<Map<String, Object>> getDailyStatusReportsForEmployeeBetweenDates(Long empId, Timestamp startDate, Timestamp endDate, Pageable pageable);
    ResponseEntity<Map<String, Object>> pendingStatus(String status, Pageable pageable);
    ResponseEntity<Map<String, Object>> pendingReports();
    ResponseEntity<Map<String, Object>> pendingStatusBetweenDates(Timestamp fromDate, Timestamp toDate,String status ,Pageable pageable);
}
