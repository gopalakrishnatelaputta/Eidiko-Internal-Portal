package com.eidiko.taskstatus.serviceimpl;

import com.eidiko.taskstatus.dto.DailyStatusReportDto;
import com.eidiko.taskstatus.entities.DailyStatusReport;
import com.eidiko.taskstatus.entities.Employee;
import com.eidiko.taskstatus.entities.TaskStatusExemptionEmp;
import com.eidiko.taskstatus.exception.*;
import com.eidiko.taskstatus.helper.ConstantValues;
import com.eidiko.taskstatus.helper.Loop;
import com.eidiko.taskstatus.repository.DailyStatusRepository;
import com.eidiko.taskstatus.repository.EmployeeRepository;
import com.eidiko.taskstatus.repository.TaskStatusExemptionRepository;
import com.eidiko.taskstatus.service.ServiceClass;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Service
public class ServiceClassImpl implements ServiceClass {

    @Autowired
    private DailyStatusRepository dailyStatusRepository;

    @Autowired
    private EmployeeRepository employeeRepository;


    @Autowired
    private TaskStatusExemptionRepository taskStatusExemptionRepository;

    private final Logger logger = LoggerFactory.getLogger(getClass());
    @Override
    public ResponseEntity<Map<String, Object>> getAll(Pageable pageable) {
        Page<DailyStatusReport> page = this.dailyStatusRepository.findAll(pageable);

        return Loop.forLoop(page);
    }


    @Override
    public ResponseEntity<Map<String, Object>> findByDate(Timestamp fromDate, Timestamp toDate, Pageable pageable) {
        Page<DailyStatusReport> page = this.dailyStatusRepository.findByStatusReportDateBetween(fromDate, toDate, pageable);

       return  Loop.forLoop(page);
    }

    @Override
    public void updateAllDailyStatus(List<Long> taskDetailsId, long verifiedById) {
        List<DailyStatusReport> dailyStatusReports=this.dailyStatusRepository.findAllById(taskDetailsId);

    if(dailyStatusReports.size()>0) {
        for (DailyStatusReport reports : dailyStatusReports) {
            Employee verifiedBy = this.employeeRepository.findById(verifiedById).orElseThrow(() -> new UserNotFoundException(ConstantValues.USER_NOT_FOUND + ConstantValues.WITH_GIVEN_ID + verifiedById));

            reports.setVerifiedBy(verifiedBy);
            this.dailyStatusRepository.save(reports);
        }

    }
    else{
        logger.error(ConstantValues.NOT_SELECTED);
        throw new DataNotFoundException(ConstantValues.NOT_SELECTED);

    }
    }




    @Override
    public void add(DailyStatusReportDto dailyStatusReportDto, long empId) throws ReportAlreadyExistsException, NotNullException {
        Employee employee = employeeRepository.findById(empId).orElseThrow(() -> new UserNotFoundException(ConstantValues.USER_NOT_FOUND +ConstantValues.WITH_GIVEN_ID + empId));

        TaskStatusExemptionEmp taskStatusExemptionEmp = this.taskStatusExemptionRepository.findByEmployeeEmpId(empId);
        if (taskStatusExemptionEmp == null) {
            throw new NotEligibleException(ConstantValues.NOT_ELIGIBLE);
        } else {
            LocalDate currentDate = LocalDate.now();
            boolean endDateExists = (taskStatusExemptionEmp.getEndDate() != null);
            if ((currentDate.isAfter(taskStatusExemptionEmp.getStartDate())|| currentDate.isEqual(taskStatusExemptionEmp.getStartDate())) && (!endDateExists || currentDate.isBefore(taskStatusExemptionEmp.getEndDate()))) {
                Employee assignedBy = employeeRepository.findById(dailyStatusReportDto.getTaskAssignedBy()).orElseThrow(() -> new UserNotFoundException(ConstantValues.USER_NOT_FOUND + ConstantValues.WITH_GIVEN_ID + dailyStatusReportDto.getTaskAssignedBy()));

                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = dateFormat.format(timestamp);

                Timestamp newTimestamp = Timestamp.valueOf(formattedDate + " 00:00:00");

                Optional<DailyStatusReport> existingReport = dailyStatusRepository.findByStatusReportDateAndEmployee(newTimestamp, employee);
                if (existingReport.isPresent()) {

                   // logger.error(ConstantValues.REPORT + new ReportAlreadyExistsException());

                    throw new ReportAlreadyExistsException(ConstantValues.REPORT);

                }
                    DailyStatusReport dailyStatusReport = new DailyStatusReport(dailyStatusReportDto);

                if(dailyStatusReport.getStatus().equalsIgnoreCase("no")&& dailyStatusReport.getReason()==null){
                    throw new NotNullException(ConstantValues.REASON);
                }

                    dailyStatusReport.setEmployee(employee);
                    dailyStatusReport.setAssignedBy(assignedBy);
                    dailyStatusReport.setStatusReportDate(newTimestamp);
                if (dailyStatusReport.getEmployee() == dailyStatusReport.getAssignedBy()) {
                    throw new NotEligibleException(ConstantValues.SHOULD_NOT_SAME);
                }


                //logger.info(ConstantValues.RESULT + dailyStatusReportDto);

                dailyStatusRepository.save(dailyStatusReport);


            } else {

               // logger.error(ConstantValues.NOT_ELIGIBLE + new NotEligibleException());

                throw new NotEligibleException(ConstantValues.NOT_ELIGIBLE);
            }
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> getDailyStatusReportsForEmployeeBetweenDates(Long empId, Timestamp startDate, Timestamp endDate, Pageable pageable) {
        Employee employee = employeeRepository.findById(empId).orElseThrow(() -> new UserNotFoundException(ConstantValues.USER_NOT_FOUND + ConstantValues.WITH_GIVEN_ID+ empId));

        Page<DailyStatusReport> page = this.dailyStatusRepository.findByEmployeeAndStatusReportDateBetween(employee, startDate, endDate, pageable);

         return Loop.forLoop(page);
    }

    @Override
    @Transactional
    public ResponseEntity<Map<String, Object>> getByEmpId(long empId, Pageable pageable) {
        Employee employee = employeeRepository.findById(empId).orElseThrow(() -> new UserNotFoundException(ConstantValues.USER_NOT_FOUND + ConstantValues.WITH_GIVEN_ID + empId));
        Page<DailyStatusReport> page = dailyStatusRepository.findByEmployee(employee, pageable);

       return  Loop.forLoop(page);
    }


    @Override
    public ResponseEntity<Map<String, Object>> pendingReportsBetweenDates(Timestamp fromDate, Timestamp toDate) {
        List<DailyStatusReport> list = this.dailyStatusRepository.findByStatusReportDateBetween(fromDate, toDate);

        return Loop.ifLoop(list);

    }

    @Override
    public ResponseEntity<Map<String, Object>> pendingReports() {
        List<DailyStatusReport> list = this.dailyStatusRepository.findAll();

        return Loop.ifLoop(list);

    }

    @Override
    public ResponseEntity<Map<String, Object>> pendingStatusBetweenDates(Timestamp fromDate, Timestamp toDate,String status ,Pageable pageable) {
        Page<DailyStatusReport> page = this.dailyStatusRepository.findByStatusReportDateBetweenAndStatus(fromDate, toDate,status, pageable);

       return  Loop.forLoop(page);

    }

    @Override
    public ResponseEntity<Map<String, Object>> pendingStatus(String status, Pageable pageable) {
        Page<DailyStatusReport> page = this.dailyStatusRepository.findByStatus( status, pageable);

       return Loop.forLoop(page);

    }
}