package com.eidiko.taskstatus.helper;

import com.eidiko.taskstatus.dto.DailyStatusReportResponseDto;
import com.eidiko.taskstatus.entities.DailyStatusReport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class Loop {

    private final static Logger logger = LoggerFactory.getLogger(Loop.class);

    private static final Map<String, Object> map = new HashMap<>();
    public static ResponseEntity< Map<String, Object>> forLoop(Page<DailyStatusReport> page) {



        List<DailyStatusReportResponseDto> responseList = new ArrayList<>();
        for (DailyStatusReport d : page) {
            DailyStatusReportResponseDto dailyStatusReportResponseDto = new DailyStatusReportResponseDto();
            dailyStatusReportResponseDto.setTaskDetailsId(d.getTaskDetailsId());
            dailyStatusReportResponseDto.setDesc(d.getDesc());
            dailyStatusReportResponseDto.setStatus(d.getStatus());
            dailyStatusReportResponseDto.setReason(d.getReason());
            dailyStatusReportResponseDto.setTeam(d.getTeam());
            dailyStatusReportResponseDto.setEmpId(d.getEmployee().getEmpId());
            dailyStatusReportResponseDto.setStatusReportDate(d.getStatusReportDate());
            dailyStatusReportResponseDto.setTaskDetail(d.getTaskDetails());
            if (d.getVerifiedBy() != null) {
                dailyStatusReportResponseDto.setVerifiedBy(d.getVerifiedBy().getEmpId());
                dailyStatusReportResponseDto.setVerifiedByName(d.getVerifiedBy().getEmpName());
            } else {
                dailyStatusReportResponseDto.setVerifiedBy(null);
            }
            dailyStatusReportResponseDto.setAssignedDate(d.getAssignedDate());
            dailyStatusReportResponseDto.setAssignedBy(d.getAssignedBy().getEmpId());
            dailyStatusReportResponseDto.setAssignedByName(d.getAssignedBy().getEmpName());
            responseList.add(dailyStatusReportResponseDto);
        }
        if (!page.isEmpty()) {
            map.put(ConstantValues.RESULT, responseList);
            map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
            map.put(ConstantValues.MESSAGE, ConstantValues.SUCCESS_MESSAGE);
            map.put(ConstantValues.STATUS_CODE, ConstantValues.STATUS_MESSAGE);

        } else {
            map.put(ConstantValues.RESULT, responseList);
            map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
            map.put(ConstantValues.MESSAGE, ConstantValues.FAILED_MESSAGE);
            map.put(ConstantValues.STATUS_CODE, ConstantValues.STATUS_MESSAGE);
        }
        map.put(ConstantValues.CURRENT_PAGE, page.getNumber());
        map.put(ConstantValues.TOTAL_ITEMS, page.getTotalElements());
        map.put(ConstantValues.TOTAL_PAGES, page.getTotalPages());
        logger.info(ConstantValues.RESULT + ResponseEntity.ok(map));
        return ResponseEntity.ok(map);

    }

    public static ResponseEntity<Map<String , Object>> ifLoop(List<DailyStatusReport> list) {

        List<DailyStatusReportResponseDto> responseList = new ArrayList<>();
        for (DailyStatusReport d : list) {
            DailyStatusReportResponseDto dailyStatusReportResponseDto = new DailyStatusReportResponseDto();

            if (d.getVerifiedBy() == null) {
                dailyStatusReportResponseDto.setTaskDetailsId(d.getTaskDetailsId());
                dailyStatusReportResponseDto.setDesc(d.getDesc());
                dailyStatusReportResponseDto.setStatus(d.getStatus());
                dailyStatusReportResponseDto.setReason(d.getReason());
                dailyStatusReportResponseDto.setTeam(d.getTeam());
                dailyStatusReportResponseDto.setEmpId(d.getEmployee().getEmpId());
                dailyStatusReportResponseDto.setStatusReportDate(d.getStatusReportDate());
                dailyStatusReportResponseDto.setTaskDetail(d.getTaskDetails());
                dailyStatusReportResponseDto.setAssignedDate(d.getAssignedDate());
                dailyStatusReportResponseDto.setAssignedBy(d.getAssignedBy().getEmpId());
                dailyStatusReportResponseDto.setAssignedByName(d.getAssignedBy().getEmpName());
                responseList.add(dailyStatusReportResponseDto);

            }

        }

        if (!list.isEmpty()) {
            map.put(ConstantValues.RESULT, responseList);
            map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
            map.put(ConstantValues.MESSAGE, ConstantValues.SUCCESS_MESSAGE);
            map.put(ConstantValues.STATUS_CODE, ConstantValues.STATUS_MESSAGE);

        } else {
            map.put(ConstantValues.RESULT, responseList);
            map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
            map.put(ConstantValues.MESSAGE, ConstantValues.FAILED_MESSAGE);
            map.put(ConstantValues.STATUS_CODE, ConstantValues.STATUS_MESSAGE);
        }
        logger.info(ConstantValues.RESULT + ResponseEntity.ok(map));
        return ResponseEntity.ok(map);

    }
}
