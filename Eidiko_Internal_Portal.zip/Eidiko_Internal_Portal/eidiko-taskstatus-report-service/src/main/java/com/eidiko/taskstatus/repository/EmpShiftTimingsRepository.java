/*
package com.eidiko.taskstatus.repository;

import com.eidiko.taskstatus.entities.EmpShiftTimings;
import com.eidiko.taskstatus.entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public interface EmpShiftTimingsRepository extends JpaRepository<EmpShiftTimings,Long> {

     public List<EmpShiftTimings>findByEmployeeEmpIdAndStartDateAndEndDate(long empId ,LocalDate startDate,LocalDate endDate);
     public List<EmpShiftTimings>findByEmployee(Employee employee);

     @Query("SELECT e FROM EmpShiftTimings e JOIN e.employee s WHERE s.empId= :empId AND e.startDate <= :toDate AND e.endDate >= :fromDate")
     List<EmpShiftTimings> findByEmpIdAndDateRange(@Param("empId")long empId,@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate);

     public List<EmpShiftTimings>findByStartDateLessThanAndEndDateGreaterThanAndEmployee(LocalDate fromDate,LocalDate toDate,Employee employee);
}
*/
