package com.eidiko.taskstatus.repository;

import com.eidiko.taskstatus.entities.DailyStatusReport;
import com.eidiko.taskstatus.entities.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
public interface DailyStatusRepository extends JpaRepository<DailyStatusReport, Long> {

    Optional<DailyStatusReport> findByStatusReportDateAndEmployee(Timestamp date, Employee employee);

    Page<DailyStatusReport> findByStatusReportDateBetween(Timestamp fromStatusReportDate, Timestamp toStatusReportDate, Pageable pageable);

   // @Query("SELECT d FROM DailyStatusReport d WHERE d.employee = :employee AND d.statusReportDate BETWEEN :fromStatusReportDate AND :toStatusReportDate")
    Page<DailyStatusReport> findByEmployeeAndStatusReportDateBetween(Employee employee, Timestamp fromStatusReportDate, Timestamp toStatusReportDate, Pageable pageable);

    Page<DailyStatusReport> findByEmployee(Employee employee, Pageable pageable);

    Page<DailyStatusReport> findByStatusReportDateBetweenAndStatus(Timestamp fromStatusReportDate, Timestamp toStatusReportDate, String status, Pageable pageable);
    Page<DailyStatusReport> findByStatus(String status, Pageable pageable);
    List<DailyStatusReport> findByStatusReportDateBetween(Timestamp fromDate,Timestamp toDate);

}

