package com.eidiko.taskstatus.exception;

public class NotEligibleException extends RuntimeException {
    public NotEligibleException() {
        super();
    }

    public NotEligibleException(String message) {
        super(message);
    }
}
