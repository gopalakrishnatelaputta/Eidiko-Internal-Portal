/*
package com.eidiko.taskstatus.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;


@Setter
@Getter
@Entity
public class EmpShiftTimings {

    @Id
    private long shiftTimingId;

    private Date startDate;
    private Date endDate;
    private Timestamp shiftStartTime;
    private Timestamp shiftEndTime;
    private long modifiedBy;

    private String weekOff;

    @JoinColumn(name = "EMP_ID")
    @OneToOne(cascade = CascadeType.ALL)
    private Employee employee;



}
*/
