package com.eidiko.taskstatus.exception;

public class ReportAlreadyExistsException extends RuntimeException {
    public ReportAlreadyExistsException() {
    }

    public ReportAlreadyExistsException(String message) {
        super(message);
    }
}
