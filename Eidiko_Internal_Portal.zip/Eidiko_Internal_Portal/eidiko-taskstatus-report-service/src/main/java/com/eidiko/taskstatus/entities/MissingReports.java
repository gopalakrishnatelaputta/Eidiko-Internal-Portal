/*
package com.eidiko.taskstatus.entities;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Date;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "daily_status_missing_reports")
public class MissingReports {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MISSING_REPORTS_ID")
    private long missingReportId;

    @JoinColumn(name = "EMP_ID")
    @ManyToOne(cascade = CascadeType.ALL)
    private Employee employee;

    @Column(name="MISSING_REPORT_DATE")
    private Date missingReportDate;

    @Column(name="IS_MISSING")
    private boolean isMissing;

    @Column(name="MODIFIED_BY")
    private String modifiedBy;


}
*/
