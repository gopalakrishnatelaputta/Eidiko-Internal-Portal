/*
package com.eidiko.taskstatus.repository;

import com.eidiko.taskstatus.entities.Employee;
import com.eidiko.taskstatus.entities.MissingReports;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.time.LocalDate;

public interface MissingReportsRepository extends JpaRepository<MissingReports,Long> {
    public MissingReports findByEmployeeAndMissingReportDate(Employee employee, Date fromdate);
//    @Query(" insert into daily_status_missing_reports ( is_missing, missing_report_date, modified_by) values ( ?, ?, ?)")
//    MissingReports save(MissingReports missingReports);
}
*/
