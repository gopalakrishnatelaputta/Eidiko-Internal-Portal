package com.eidiko.biometric.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import com.eidiko.biometric.entity.BiometricEntity;
import com.eidiko.biometric.exception.FileDataAlreadyExistsException;
import com.eidiko.biometric.helper.ConstantValues;
import com.eidiko.biometric.repository.BiometricRepository;
import com.eidiko.biometric.service.BiometricService;

@Service
public class BiometricServiceImpl implements BiometricService {
	@Autowired
	private BiometricRepository biorepository;

	BiometricEntity biometricEntity = new BiometricEntity();

	@Override
	public ResponseEntity<Map<String, String>> uploadFile(MultipartFile file) {

		BufferedReader reader;

		List<BiometricEntity> list = new ArrayList<>();

		try {
			reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
			String line = reader.readLine();
			while (line != null) {
				String aaa = line.trim();
				System.out.println(aaa);

				Map<String, String> separateEmpIdAndDateFromString = separateEmpIdAndDateFromString(aaa);
				BiometricEntity generateBiometricEntity = generateBiometricEntity(
						separateEmpIdAndDateFromString.get("empId"), separateEmpIdAndDateFromString.get("dateTime"));
				System.out.println(generateBiometricEntity);
				list.add(generateBiometricEntity);
				System.out.println("-------------------------------------------------------------------");
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println(list.size());
		if (getLastRecord() == null) {
			this.biorepository.saveAll(list);
	        Map<String, String> response = new HashMap<>();
	        response.put("status", ConstantValues.STATUS);
	        response.put("message", ConstantValues.FILE_MESSAGE);
	        response.put("statuscode", ConstantValues.STATUS_CODE);
	        return ResponseEntity.ok(response);
		} else {
			List<BiometricEntity> removeDup = removeDup(getLastRecord(), list);
			System.out.println("removeDup removeDup" + " " + removeDup);
			this.biorepository.saveAll(removeDup);
			 Map<String, String> response = new HashMap<>();
		        response.put("status", ConstantValues.STATUS);
		        response.put("message", ConstantValues.FILE_MESSAGE);
		        response.put("statuscode", ConstantValues.STATUS_CODE);
		        return ResponseEntity.ok(response);
		}
		
	}

	private Map<String, String> separateEmpIdAndDateFromString(String line) {
		String[] split = line.split("\t");
		String empId = split[0].trim();
		String dateTime = split[1].trim();
		Map<String, String> map = new HashMap<>();
		map.put("empId", empId);
		map.put("dateTime", dateTime);

		return map;
	}

	private BiometricEntity generateBiometricEntity(String empId, String dateTime) {

		System.out.println(empId + "<<<>>>>" + dateTime);

		BiometricEntity biometricEntity = new BiometricEntity();
		biometricEntity.setEmpId(Long.parseLong(empId));
		Timestamp timestamp = null;
		String pattern = "yyyy-MM-dd HH:mm:ss";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		try {
			// java.util.Date date = dateFormat.parse(dateString);
			java.util.Date parseDate = sdf.parse(dateTime);
			System.out.println("parseDate" + parseDate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(parseDate);
			cal.set(Calendar.MILLISECOND, 0);
			timestamp = new Timestamp(parseDate.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}

		biometricEntity.setBioDate(timestamp);
		return biometricEntity;
	}

	public StringBuilder getLastRecord() {
		BiometricEntity lastrec = biorepository.findLastRecord();
		if (lastrec == null) {
			return null;
		}
		System.out.println("lastrec" + " " + lastrec);
		StringBuilder lastempBiodatefromDB = new StringBuilder();
		String s1 = lastrec.getEmpId().toString();
		String s2 = lastrec.getBioDate().toString();
		lastempBiodatefromDB.append(s1).append(" ");
		lastempBiodatefromDB.append(s2);
		System.out.println(lastempBiodatefromDB);
		return lastempBiodatefromDB;
	}

	private List<BiometricEntity> removeDup(StringBuilder lastempBiodatefromDB, List<BiometricEntity> list) {
		System.out.println("Inside removeDup");
		int count = 0;
		int temp = 0;
		List<BiometricEntity> filteredlist = new ArrayList<>();
		for (BiometricEntity obj : list) {
			count++;
			StringBuilder str = new StringBuilder();
			String s3 = obj.getEmpId().toString();
			String s4 = obj.getBioDate().toString();
			str.append(s3).append(" ");
			str.append(s4);
			if (str.toString().compareTo(lastempBiodatefromDB.toString()) == 0) {
				System.out.println("count" + count);
				temp = count;
			}
		}
		if(count == temp) {
			throw new FileDataAlreadyExistsException("File Data  Exists");
		}
		System.out.println(temp + "temp");
		for (int i = temp; i < list.size(); i++) {
			filteredlist.add(list.get(i));
		}
		return filteredlist;
	}

}
