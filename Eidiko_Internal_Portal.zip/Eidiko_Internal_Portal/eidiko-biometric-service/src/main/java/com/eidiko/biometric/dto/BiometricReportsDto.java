package com.eidiko.biometric.dto;

import java.sql.Timestamp;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BiometricReportsDto {
	private Long biometricReportId;
	private Long empId;
	private Date biometricDate;
	private Timestamp checkInTime;
	private Timestamp checkOutTime;
	private int totalWorkingTime;
	private Boolean isLate;
	private Timestamp modifiedOn;
	private int month;
	private int year;
	private boolean isVerylate;
	
	

}
