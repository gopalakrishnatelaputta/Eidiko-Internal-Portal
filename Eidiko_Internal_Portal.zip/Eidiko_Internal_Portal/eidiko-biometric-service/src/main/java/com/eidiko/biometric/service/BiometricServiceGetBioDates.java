package com.eidiko.biometric.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.eidiko.biometric.entity.BiometricEntity;
//import com.eidiko.biometric.entity.BiometricShiftTimingsEntity;

public interface BiometricServiceGetBioDates {

	public Map<String, Object> getBiometricDataByEmpId(Timestamp fromDate, Timestamp toDate, long empId);
	
	//public List<BiometricShiftTimingsEntity> getShiftTimings(long empId);
	

}
