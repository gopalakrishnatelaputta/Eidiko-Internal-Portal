package com.eidiko.biometric.service;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import org.springframework.data.domain.Pageable;

public interface BiometricReportService {
	
	public Map<String,Object> getAllBiometricReportsByDate(Date date , Pageable pageable);
	
	public Map<String, Object> getBioReportsFromDatetoTodateforEmp(long empId,Date fromDate,Date toDate,Pageable pageable);
	
	 
	 public Map<String, Object> getCountofisLateBiometricReportByMonth(String month ,Integer year,Pageable pageable) ;
	 
	 public Map<String, Object> updateBiometricIsLateReport(Timestamp fromDate, Timestamp toDate) throws SQLException;
	 
	 
	 public Map<String, Object> calculatedBiometricEmployeesReport(Pageable pageable,String fromDate,String toDate);
	 
	     

}
