package com.eidiko.biometric.config;

import java.util.TimeZone;

import org.modelmapper.ModelMapper;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonConfig {
	@Bean
	Jackson2ObjectMapperBuilderCustomizer jacksonObjectMapperCustomization() {
		return builder -> {
			builder.timeZone(TimeZone.getTimeZone("IST"));
		};
	}

	@Bean
	ModelMapper modelMapper() {
		return new ModelMapper();
	}
}
