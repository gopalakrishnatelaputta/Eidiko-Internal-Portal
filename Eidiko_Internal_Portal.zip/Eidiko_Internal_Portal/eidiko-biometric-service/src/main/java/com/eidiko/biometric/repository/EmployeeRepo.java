package com.eidiko.biometric.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.biometric.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {

}
