package com.eidiko.biometric.exception;

public class FileDataAlreadyExistsException extends RuntimeException {
	
	public FileDataAlreadyExistsException(String message) {
        super(message);
    }

}
