package com.eidiko.biometric.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eidiko.biometric.entity.BiometricReportEntity;
import com.eidiko.biometric.helper.BiometricReportProjection;
import com.eidiko.biometric.helper.DuplicateIdsProjection;

@Repository
public interface BiometricReportRepository extends JpaRepository<BiometricReportEntity, Long> {

	List<BiometricReportEntity> findByempId(long empId);

	BiometricReportEntity findByEmpIdAndBiometricDateAndMonthAndYear(long empid, Date date, String month, int year);

	List<BiometricReportEntity> getByempId(Object empId);

	Page<BiometricReportEntity> findByBiometricDate(Date date, Pageable pageable);

	public Page<BiometricReportEntity> findByEmpIdAndBiometricDateBetween(@Param("empId") long empId,
			@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, Pageable pageable);

	Page<BiometricReportEntity> findByMonthAndYear(String month, Integer year, Pageable pageable);

	@Query(value = "SELECT COUNT(*) as count , r.emp_id , e.emp_name FROM emp_biometric_report r,employee e WHERE  total_working_time > 540 AND r.biometric_date BETWEEN ?1 AND ?2 AND  r.emp_id = e.emp_id GROUP BY r.emp_id ORDER BY COUNT(*) DESC ", nativeQuery = true)
	Page<BiometricReportProjection> findBytotalworkingtime(String fromDate, String toDate, Integer totalworkingtime,
			Pageable pageable);

	@Query(value = "SELECT COUNT(*) as count, r.emp_id , e.emp_name FROM emp_biometric_report r,employee e WHERE  is_Late = 0 AND r.biometric_date BETWEEN ?1 AND ?2 AND  r.emp_id = e.emp_id GROUP BY r.emp_id ORDER BY COUNT(*) DESC", nativeQuery = true)
	Page<BiometricReportProjection> findByisLatefalse(String fromDate, String toDate, Pageable pageable);

	@Query(value = "SELECT COUNT(*) as count, r.emp_id , e.emp_name FROM emp_biometric_report r,employee e WHERE  is_Late = 1 AND r.biometric_date BETWEEN ?1 AND ?2 AND  r.emp_id = e.emp_id GROUP BY r.emp_id ORDER BY COUNT(*) DESC", nativeQuery = true)
	Page<BiometricReportProjection> findByisLatetrue(String fromDate, String toDate, Pageable pageable);

	@Query(value = "SELECT COUNT(*) as count , r.emp_id , e.emp_name FROM emp_biometric_report r,employee e WHERE  total_working_time < 540 AND r.biometric_date BETWEEN ?1 AND ?2 AND  r.emp_id = e.emp_id GROUP BY r.emp_id ORDER BY COUNT(*) DESC ", nativeQuery = true)
	Page<BiometricReportProjection> findBytotalworkingtimeLess9hrs(String fromDate, String toDate,
			Integer totalworkingtime, Pageable pageable);

	@Query(value = "SELECT COUNT(*) as count, r.emp_id , e.emp_name FROM emp_biometric_report r,employee e WHERE  is_very_Late = 1 AND r.biometric_date BETWEEN ?1 AND ?2 AND  r.emp_id = e.emp_id GROUP BY r.emp_id ORDER BY COUNT(*) DESC", nativeQuery = true)
	Page<BiometricReportProjection> findByisVeryLatetrue(String fromDate, String toDate, Pageable pageable);
	
	@Query(value = "SELECT BIOMETRIC_REPORT_ID\r\n"
			+ "    FROM emp_biometric_report\r\n"
			+ "    WHERE BIOMETRIC_REPORT_ID NOT IN\r\n"
			+ "    (\r\n"
			+ "SELECT MAX(BIOMETRIC_REPORT_ID)\r\n"
			+ "        FROM emp_biometric_report\r\n"
			+ "        GROUP BY emp_id, BIOMETRIC_DATE\r\n"
			+ "        )", nativeQuery = true)
	List<DuplicateIdsProjection> findDuplicatesInBiometricReport();
	

}
