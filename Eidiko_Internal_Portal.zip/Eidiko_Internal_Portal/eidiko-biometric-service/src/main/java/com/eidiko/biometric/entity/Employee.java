package com.eidiko.biometric.entity;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;


import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

	
	@Id
	private long empId;
	private String empName;
	private String emailId;
	private Date dateOfJoining;
	private Timestamp modifiedDate;
	private String contactNo;
	private long createdBy;
	private boolean isDeleted;
	private String status;

	private String about;


	@JsonIgnore
	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<EmpShiftTimings> empShiftTimings = new HashSet<>();


	
	
	
}
