package com.eidiko.biometric.service.impl;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.eidiko.biometric.entity.BiometricEntity;
import com.eidiko.biometric.helper.ConstantValues;
//import com.eidiko.biometric.entity.BiometricShiftTimingsEntity;
//import com.eidiko.biometric.repository.BiometricFromToDatebyIdRepository;
import com.eidiko.biometric.repository.BiometricRepository;
import com.eidiko.biometric.service.BiometricServiceGetBioDates;

@Service
public class BiometricServiceGetBioDatesImpl implements BiometricServiceGetBioDates {

	@Autowired
	private BiometricRepository biometricRepository;

	@Override
	public Map<String, Object> getBiometricDataByEmpId(Timestamp fromDate, Timestamp toDate, long empId) {

		List<BiometricEntity> listOfDates = biometricRepository.findByEmpIdAndBioDateBetween(empId, fromDate, toDate);
		Map<String, Object> map = new HashMap<>();
		if (!listOfDates.isEmpty()) {

			map.put(ConstantValues.RESULT, listOfDates);
			map.put(ConstantValues.MESSAGE, ConstantValues.DATA_FETCHED_SUCCESS_TEXT);
			map.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
			map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
		} else {
			map.put(ConstantValues.MESSAGE, ConstantValues.NO_DATA_FETCHED_SUCCESS_TEXT);
			map.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
			map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
			map.put(ConstantValues.RESULT, new ArrayList<>());

		}
		return map;
	}
}
