package com.eidiko.biometric.helper;

public interface DuplicateIdsProjection {
	Long getBIOMETRIC_REPORT_ID();
}
