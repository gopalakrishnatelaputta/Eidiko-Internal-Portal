package com.eidiko.biometric.service.impl;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.eidiko.biometric.dto.BiometricCalculatedResponseDto;
import com.eidiko.biometric.dto.BiometricReportsDto;
import com.eidiko.biometric.entity.BiometricEntity;
import com.eidiko.biometric.entity.BiometricExemptionEmp;
import com.eidiko.biometric.entity.BiometricReportEntity;
import com.eidiko.biometric.entity.EmpShiftTimings;
import com.eidiko.biometric.entity.Employee;
import com.eidiko.biometric.exception.EmployeeNotFoundException;
import com.eidiko.biometric.helper.BiometricReportProjection;
import com.eidiko.biometric.helper.ConstantValues;
import com.eidiko.biometric.helper.DuplicateIdsProjection;
import com.eidiko.biometric.repository.BiometricExemptionEmpRepo;
import com.eidiko.biometric.repository.BiometricReportRepository;
import com.eidiko.biometric.repository.EmployeeRepo;
import com.eidiko.biometric.service.BiometricReportService;
import com.eidiko.biometric.service.BiometricServiceGetBioDates;

@Service
public class BiometricReportServiceImpl implements BiometricReportService {

	@Autowired
	private BiometricReportRepository biometricReportRepository;

	@Autowired
	private BiometricServiceGetBioDates biometricServiceGetBioDates;

	@Autowired
	private EmployeeRepo employeeRepo;
	
	@Autowired
	private BiometricExemptionEmpRepo biometricExemptionEmpRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public Map<String, Object> getBioReportsFromDatetoTodateforEmp(long empId, Date fromDate, Date toDate,
			Pageable pageable) {
		Map<String, Object> map = new HashMap<>();
		List<BiometricReportEntity> empIdData = biometricReportRepository.findByempId(empId);
		if (empIdData.isEmpty()) {
			System.out.println("Not Exist");
			System.out.println(empId + "empID");
			throw new EmployeeNotFoundException("Employee Not Found ");

		}

		Page<BiometricReportEntity> page = biometricReportRepository.findByEmpIdAndBiometricDateBetween(empId, fromDate,
				toDate, pageable);

		if (page.hasContent()) {
			map.put(ConstantValues.RESULT, page.getContent());
			map.put(ConstantValues.MESSAGE, ConstantValues.DATA_FETCHED_SUCCESS_TEXT);
			map.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
			map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
			map.put("totalPages", page.getTotalPages());
			map.put("noOfElements", page.getNumberOfElements());
			map.put("pageSize", page.getSize());
			map.put("totalElements", page.getTotalElements());
			map.put("isFirst", page.isFirst());
			map.put("isLast", page.isLast());

			return map;
		}

		else {

			map.put(ConstantValues.MESSAGE, ConstantValues.NO_DATA_FETCHED_SUCCESS_TEXT);
			map.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
			map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
			map.put(ConstantValues.RESULT, new ArrayList<>());
			return map;
		}

	}

	public boolean isEmpIdNotExists(int empId) {
		List<BiometricReportEntity> biometricReportEntities = biometricReportRepository.getByempId(empId);
		return biometricReportEntities == null;
	}

	@Override
	public Map<String, Object> getAllBiometricReportsByDate(Date date, Pageable pageable) {
		Map<String, Object> map = new HashMap<>();

		Page<BiometricReportEntity> pageable2 = this.biometricReportRepository.findByBiometricDate(date, pageable);
		if (pageable2.hasContent()) {
			map.put(ConstantValues.RESULT, pageable2.getContent());
			map.put(ConstantValues.MESSAGE, ConstantValues.DATA_FETCHED_SUCCESS_TEXT);
			map.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
			map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
			map.put("totalPages", pageable2.getTotalPages());
			map.put("noOfElements", pageable2.getNumberOfElements());
			map.put("pageSize", pageable2.getSize());
			map.put("totalElements", pageable2.getTotalElements());
			map.put("isFirst", pageable2.isFirst());
			map.put("isLast", pageable2.isLast());
			return map;
		}
		map.put(ConstantValues.MESSAGE, ConstantValues.NO_DATA_FETCHED_SUCCESS_TEXT);
		map.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
		map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
		map.put(ConstantValues.RESULT, new ArrayList<>());

		return map;
	}

	@Override
	public Map<String, Object> getCountofisLateBiometricReportByMonth(String month, Integer year, Pageable pageable) {

		if (year == null) {
			year = Year.now().getValue();
		}
		System.out.println("YEARYAERYAER" + "  " + year);
		Page<BiometricReportEntity> reports = biometricReportRepository.findByMonthAndYear(month, year, pageable);
		Map<String, Object> responseMap = new HashMap<>();
		Map<Long, Integer> counts = new HashMap<>();
		for (BiometricReportEntity report : reports) {
			if (report.getIsLate() == true) {
				Long empId = report.getEmpId();
				counts.put(empId, counts.getOrDefault(empId, 0) + 1);
			}
		}
		List<Map<String, Object>> result = new ArrayList<>();
		for (Long empId : counts.keySet()) {
			Map<String, Object> row = new HashMap<>();
			row.put("empId", empId);
			row.put("countOfIsLate", counts.get(empId));
			result.add(row);
		}
		Collections.sort(result, new Comparator<Map<String, Object>>() {
			@Override
			public int compare(Map<String, Object> o1, Map<String, Object> o2) {
				Long empId1 = (Long) o1.get("empId");
				Long empId2 = (Long) o2.get("empId");
				return empId1.compareTo(empId2);
			}
		});
		if (reports.hasContent()) {
			responseMap.put(ConstantValues.RESULT, result);
			responseMap.put(ConstantValues.MESSAGE, ConstantValues.DATA_FETCHED_SUCCESS_TEXT);
			responseMap.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
			responseMap.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
			responseMap.put("totalPages", reports.getTotalPages());
			responseMap.put("noOfElements", reports.getNumberOfElements());
			responseMap.put("pageSize", reports.getSize());
			responseMap.put("totalElements", reports.getTotalElements());
			responseMap.put("isFirst", reports.isFirst());
			responseMap.put("isLast", reports.isLast());
			return responseMap;
		}

		responseMap.put(ConstantValues.MESSAGE, ConstantValues.NO_DATA_FETCHED_SUCCESS_TEXT);
		responseMap.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
		responseMap.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
		responseMap.put(ConstantValues.RESULT, new ArrayList<>());

		return responseMap;
	}

	@Override
	public Map<String, Object> updateBiometricIsLateReport(Timestamp fromDate, Timestamp toDate) throws SQLException {
		System.out.println(">>>>>>>>>> Inside report service Implementation");

		// 1. Get All Employees list
		List<Employee> employeeList = this.employeeRepo.findAll();

		int year = fromDate.getYear();

		// 2. Initialize total Biometric Report list
		List<BiometricReportsDto> totalList = new ArrayList<>();
		for (Employee employee : employeeList) {

			Map<String, Object> biometricDataByEmpId = this.biometricServiceGetBioDates
					.getBiometricDataByEmpId(fromDate, toDate, employee.getEmpId());
			List<BiometricEntity> biometricData = (List<BiometricEntity>) biometricDataByEmpId
					.get(ConstantValues.RESULT);
			Set<EmpShiftTimings> empShiftTimings = employee.getEmpShiftTimings();
			List<BiometricReportsDto> isLateReport = calculateBiometricIsLateReport(employee.getEmpId(), biometricData,
					empShiftTimings, year);

			totalList.addAll(isLateReport);

		}

		List<BiometricReportEntity> biometricReportEntities = new ArrayList<>();
		totalList.forEach(b -> {
			b.setModifiedOn(new Timestamp(System.currentTimeMillis()));
			biometricReportEntities.add(this.modelMapper.map(b, BiometricReportEntity.class));
		});
		try {
			//this.biometricReportRepository.saveAll(biometricReportEntities);
			deleteDuplicateRecord();
		} catch (Exception e) {
			throw new SQLException(e.getMessage());
		}

		Map<String, Object> map = new HashMap<>();
		map.put(ConstantValues.MESSAGE, "Data Successfully Updated...");
		map.put("statusMessage", ConstantValues.SUCCESS_MESSAGE);
		map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
		return map;
	}

	private List<BiometricReportsDto> calculateBiometricIsLateReport(long empId, List<BiometricEntity> biometricData,
			Set<EmpShiftTimings> shiftTimingsSet, int year) {

		List<BiometricReportsDto> reportList = new ArrayList<>();

		Calendar today = Calendar.getInstance();
		Calendar calculateDate = Calendar.getInstance();
		calculateDate.set(ConstantValues.PORTAL_DEFAULT_CALCULATION_YEAR, Calendar.JANUARY, 1, 1, 1);

		for (; calculateDate.before(today); calculateDate.add(Calendar.DATE, 1)) {
			Time startTime = getShiftStartTime(calculateDate.getTime(), shiftTimingsSet);
			Calendar biometricStartTime = Calendar.getInstance();
			biometricStartTime.setTimeInMillis(calculateDate.getTimeInMillis());
			biometricStartTime.set(Calendar.HOUR_OF_DAY, startTime.getHours() - 3);
			biometricStartTime.set(Calendar.MINUTE, startTime.getMinutes());
			Calendar biometricEndDate = Calendar.getInstance();
			biometricEndDate.setTimeInMillis(biometricStartTime.getTimeInMillis());
			biometricEndDate.add(Calendar.HOUR_OF_DAY, 24);

			List<java.util.Date> biometricDateList = filterBiometricData(biometricData, biometricStartTime,
					biometricEndDate);

			if (!biometricDateList.isEmpty()) {
				BiometricReportsDto reportsDto = new BiometricReportsDto();
				reportsDto.setBiometricDate(calculateDate.getTime());
				reportsDto.setEmpId(empId);
				reportsDto.setMonth(calculateDate.get(Calendar.MONTH));
				reportsDto.setYear(calculateDate.get(Calendar.YEAR));
				long checkInTime = biometricDateList.get(0).getTime();
				long checkOutTime = biometricDateList.get(biometricDateList.size() - 1).getTime();
				reportsDto.setCheckInTime(new Timestamp(checkInTime));
				reportsDto.setCheckOutTime(new Timestamp(checkOutTime));
				Calendar checkinCal = Calendar.getInstance();
				checkinCal.setTimeInMillis(checkInTime);
				Calendar shiftTime = Calendar.getInstance();
				shiftTime.setTimeInMillis(biometricStartTime.getTimeInMillis());
				shiftTime.add(Calendar.HOUR_OF_DAY, 3);
				if (checkinCal.after(shiftTime)) {
					reportsDto.setIsLate(true);
				} else {
					reportsDto.setIsLate(false);
				}
				shiftTime.add(Calendar.MINUTE, 30);
				if (checkinCal.after(shiftTime)) {
					reportsDto.setVerylate(true);
				} else {
					reportsDto.setVerylate(false);
				}
				int minutes = (int) ((checkOutTime - checkInTime) / (60 * 1000));
				reportsDto.setTotalWorkingTime(minutes);

				reportList.add(reportsDto);
			}

		}
		return reportList;

	}

	private List<java.util.Date> filterBiometricData(List<BiometricEntity> biometricDataList,
			Calendar biometricStartTime, Calendar biometricEndDate) {
		List<java.util.Date> filteredData = new ArrayList<>();
		for (BiometricEntity biometricData : biometricDataList) {
			Timestamp bioDate = biometricData.getBioDate();
			SimpleDateFormat op = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
			Calendar biometricDate = formatDate(op.format(bioDate));
			if (biometricStartTime.after(biometricDate)) {
				continue;
			}
			if (biometricEndDate.before(biometricDate)) {
				break;
			}
			filteredData.add(biometricDate.getTime());
		}

		return filteredData;
	}

	private Calendar formatDate(String bioDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		Calendar cal = Calendar.getInstance();
		try {
			java.util.Date d = sdf.parse(bioDate);
			cal.setTime(d);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return cal;
	}

	private Time getShiftStartTime(java.util.Date calulatedDate, Set<EmpShiftTimings> shiftTimingsSet) {

		for (EmpShiftTimings empShiftTimings : shiftTimingsSet) {
			java.util.Date startDate = empShiftTimings.getStartDate();
			java.util.Date endDate = empShiftTimings.getEndDate();
			if (endDate == null) {
				endDate = Calendar.getInstance().getTime();
			}
			if (calulatedDate.after(startDate) && calulatedDate.before(endDate)) {
				return empShiftTimings.getShiftStartTime();
			}
		}

		return new Time(10, 0, 0);
	}

	private boolean deleteDuplicateRecord() throws SQLException {
		List<DuplicateIdsProjection> biometricReportIds = this.biometricReportRepository.findDuplicatesInBiometricReport();
		List<Long> reportIds = new ArrayList<>();
		for(DuplicateIdsProjection l:biometricReportIds) {
			reportIds.add(l.getBIOMETRIC_REPORT_ID());
		}
		try {
			this.biometricReportRepository.deleteAllById(reportIds);
		} catch (Exception e) {
			throw new SQLException("Resource not processed ...");
		}
		return false;

	}

	@Override
	public Map<String, Object> calculatedBiometricEmployeesReport(Pageable pageable, String fromDate, String toDate) {
		System.out.println("Inside getAllBiometricReportsOfNonLateEmps method");

		Page<BiometricReportProjection> nonLateEmps = biometricReportRepository.findByisLatefalse(fromDate, toDate,
				pageable);

		Page<BiometricReportProjection> late = biometricReportRepository.findByisLatetrue(fromDate, toDate, pageable);

		Page<BiometricReportProjection> greaterThan9Hrs = biometricReportRepository.findBytotalworkingtime(fromDate,
				toDate, 540, pageable);

		Page<BiometricReportProjection> lessThan9hrs = biometricReportRepository
				.findBytotalworkingtimeLess9hrs(fromDate, toDate, 540, pageable);

		Page<BiometricReportProjection> veryLatetrue = biometricReportRepository.findByisVeryLatetrue(fromDate, toDate,
				pageable);

		List<Employee> employees = this.employeeRepo.findAll();

		Map<String, Object> map = new HashMap<>();

		List<BiometricCalculatedResponseDto> biometricCalculatedResponseDtos = new ArrayList<>();
		List<BiometricExemptionEmp> empBiosExemptionsList = this.biometricExemptionEmpRepo.findAll();
		
		for (Employee e : employees) {

			if(validateEmpBioExemption(empBiosExemptionsList, e.getEmpId())) {
				continue;
			}
			
			BiometricCalculatedResponseDto responseDto = new BiometricCalculatedResponseDto();
			responseDto.setEmpId(e.getEmpId());
			responseDto.setEmpName(e.getEmpName());

			Page<BiometricReportEntity> bioReportData = biometricReportRepository.findByEmpIdAndBiometricDateBetween(
					e.getEmpId(), getDateFromatFromString(fromDate), getDateFromatFromString(toDate), pageable);
			long workTime = 0;
			long count = bioReportData.getContent().size();
			for (BiometricReportEntity b : bioReportData) {
				workTime = workTime + Long.parseLong(b.getTotalWorkingTime());
			}
			System.out.println(workTime + "-----------------" + bioReportData.getContent().size());
			if (workTime > 0 && count > 0) {
				responseDto.setAvgworkingMinutes(workTime / bioReportData.getContent().size());
			}
			for (BiometricReportProjection b : nonLateEmps) {
				if (b.getemp_id() == e.getEmpId()) {
					responseDto.setNonLateCount(b.getcount());
				}
			}
			for (BiometricReportProjection b : late) {
				if (b.getemp_id() == e.getEmpId()) {
					responseDto.setLateCount(b.getcount());
				}
			}
			for (BiometricReportProjection b : greaterThan9Hrs) {
				if (b.getemp_id() == e.getEmpId()) {
					responseDto.setGreaterThanWrkHrsCount(b.getcount());
				}
			}
			for (BiometricReportProjection b : lessThan9hrs) {
				if (b.getemp_id() == e.getEmpId()) {
					responseDto.setLessThanWrkHrsCount(b.getcount());
				}
			}
			for (BiometricReportProjection b : veryLatetrue) {
				if (b.getemp_id() == e.getEmpId()) {
					responseDto.setVeryLateCount(b.getcount());
				}
			}
			if(count > 0) {
				biometricCalculatedResponseDtos.add(responseDto);
			}

		}

		map.put(ConstantValues.MESSAGE, ConstantValues.DATA_FETCHED_SUCCESS_TEXT);
		map.put(ConstantValues.STATUS_CODE, ConstantValues.SUCCESS_MESSAGE);
		map.put(ConstantValues.STATUS_TEXT, HttpStatus.OK.value());
		map.put(ConstantValues.RESULT, biometricCalculatedResponseDtos);
		return map;

	}

	public Date getDateFromatFromString(String date) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date parsedDate = dateFormat.parse(date);
			return new java.sql.Date(parsedDate.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
	
	private boolean validateEmpBioExemption(List<BiometricExemptionEmp> biometricExemptionEmps, long empId) {
		for(BiometricExemptionEmp be:biometricExemptionEmps) {
			if(be.getEmpId() == empId) {
				return true;
			}
		}
		return false;
	}

}
