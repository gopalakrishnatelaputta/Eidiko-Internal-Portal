package com.eidiko.biometric;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;


@SpringBootApplication
@OpenAPIDefinition(info = @Info (title = "Biometric Service", version = "1.0.0", description = "This is for For Employee Biometric details",
termsOfService = "eidiko",contact = @Contact(name="eidiko ",email=""),license = @License(name = "eidiko",url = "eidikourl")))
public class EidikoBiometricServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EidikoBiometricServiceApplication.class, args);
	}

}
