package com.eidiko.biometric.helper;

import java.util.Calendar;

public class ConstantValues {
	public static final String FILESUCCESS_MESSAGE = " Data Uploaded successfully";
	public static final String SUCCESS_MESSAGE = " Success";
	public static final String MESSAGE = "message";
    public static final String FAILED_MESSAGE = "No data found";
    public static final String STATUS = "Success";
    public static final String FILE_MESSAGE = "File Data Uploaded successfully";
    public static final String REPORT = "File Data Already Exists";
    public static final String NO_CONTENT = "Data does not Exists";
    public static final String STATUS_CODE = "200";
    public static final String SUCCESSRESPONSE = "Response";
    public static final String EMPLOYEE_NOT_FOUND = "Employee Data not found with this Id";
	public static final String RESULT = "result";
	public static final String STATUS_TEXT = "status";
	public static final Object DATA_FETCHED_SUCCESS_TEXT = "Data fetched successfully";
	public static final Object NO_DATA_FETCHED_SUCCESS_TEXT = "No Data Available";
	
	public static final int PORTAL_DEFAULT_CALCULATION_YEAR = 2023;
	
	
}
