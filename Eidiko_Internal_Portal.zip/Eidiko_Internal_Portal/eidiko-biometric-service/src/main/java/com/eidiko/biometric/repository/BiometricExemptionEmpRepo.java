package com.eidiko.biometric.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.biometric.entity.BiometricExemptionEmp;

public interface BiometricExemptionEmpRepo extends JpaRepository<BiometricExemptionEmp, Long>{

}
