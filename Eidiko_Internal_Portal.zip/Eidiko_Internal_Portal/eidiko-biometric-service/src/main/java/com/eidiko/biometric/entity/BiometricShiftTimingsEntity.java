/*
 * package com.eidiko.biometric.entity;
 * 
 * import java.sql.Time; import java.time.LocalDate;
 * 
 * import jakarta.persistence.Entity; import jakarta.persistence.Table;
 * 
 * 
 * 
 * @Entity
 * 
 * @Table(name="emp_shift_timings") public class BiometricShiftTimingsEntity {
 * 
 * //@Id
 * 
 * private Long empId; private LocalDate startDate; private LocalDate endDate;
 * private Time shiftStartTime; private Time shiftEndTime;
 * 
 * 
 * public BiometricShiftTimingsEntity() { super(); // TODO Auto-generated
 * constructor stub }
 * 
 * public BiometricShiftTimingsEntity(Long empId, LocalDate startDate, LocalDate
 * endDate, Time shiftStartTime, Time shiftEndTime) { super(); this.empId =
 * empId; this.startDate = startDate; this.endDate = endDate;
 * this.shiftStartTime = shiftStartTime; this.shiftEndTime = shiftEndTime; }
 * 
 * public Long getEmpId() { return empId; } public void setEmpId(Long empId) {
 * this.empId = empId; } public LocalDate getStartDate() { return startDate; }
 * public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
 * public LocalDate getEndDate() { return endDate; } public void
 * setEndDate(LocalDate endDate) { this.endDate = endDate; } public Time
 * getShiftStartTime() { return shiftStartTime; } public void
 * setShiftStartTime(Time shiftStartTime) { this.shiftStartTime =
 * shiftStartTime; } public Time getShiftEndTime() { return shiftEndTime; }
 * public void setShiftEndTime(Time shiftEndTime) { this.shiftEndTime =
 * shiftEndTime; }
 * 
 * 
 * 
 * 
 * 
 * }
 */