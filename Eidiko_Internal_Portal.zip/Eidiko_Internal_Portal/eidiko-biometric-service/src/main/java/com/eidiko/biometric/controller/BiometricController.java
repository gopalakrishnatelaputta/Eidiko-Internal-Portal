package com.eidiko.biometric.controller;

import java.sql.Date;

import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.eidiko.biometric.dto.BiometricReportsByDateAndisLateSuccessResponseDto;
import com.eidiko.biometric.dto.FileSuccessResponseDto;
import com.eidiko.biometric.entity.BiometricEntity;
import com.eidiko.biometric.entity.BiometricReportEntity;
import com.eidiko.biometric.exception.BadRequestException;
import com.eidiko.biometric.helper.BiometricReportProjection;
import com.eidiko.biometric.repository.BiometricReportRepository;
import com.eidiko.biometric.service.BiometricService;
import com.eidiko.biometric.service.impl.BiometricReportServiceImpl;
import com.eidiko.biometric.service.impl.BiometricServiceGetBioDatesImpl;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Size;

@RestController
@RequestMapping("/api/v1/biometric")
public class BiometricController {
	@Autowired
	private  BiometricReportRepository biometricReportRepository;

	@Autowired
	private BiometricService biometricService;

	@Autowired
	private BiometricServiceGetBioDatesImpl biometricServiceGetBioDatesImpl;

	@Autowired
	BiometricReportServiceImpl biometricReportServiceImpl;

	@RequestMapping(value = "/fileupload", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@Operation(summary = "Upload BiometricData file", description = "To Upload BiometricData File", tags = "Post")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "File Uploaded Successfully", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = FileSuccessResponseDto.class)) }) })
	public ResponseEntity<Map<String, String>> fileRead(@RequestParam(value = "file") MultipartFile file) {
		System.out.println("Inside FileRead method");
		if (file.isEmpty()) {
			throw new NullPointerException();
		}
		ResponseEntity<Map<String, String>> uploadFile = biometricService.uploadFile(file);
		return uploadFile;
	}

	@GetMapping("/biometricDatabyIdDate/{empId}/{fromDate}/{toDate}")
	public Map<String,Object> getBiometricDataByEmpIds(
			@PathVariable("fromDate") @DateTimeFormat(iso = ISO.DATE_TIME) String fromDate,
			@PathVariable("toDate") @DateTimeFormat(iso = ISO.DATE_TIME) String toDate,
			@PathVariable("empId") long empId) {
		System.out.println("Inside getBiometricDataByEmpIds method");
		LocalDate todate = LocalDate.parse(toDate).plusDays(1);
		LocalDate fromDate1 = LocalDate.parse(fromDate);
		Timestamp timestamp = Timestamp.valueOf(todate.atStartOfDay());
		Timestamp timestamp1 = Timestamp.valueOf(fromDate1.atStartOfDay());
		System.out.println(timestamp);
		System.out.println(timestamp1);
		System.out.println(empId);
		return biometricServiceGetBioDatesImpl.getBiometricDataByEmpId(timestamp1,
				timestamp, empId);
	}

	@GetMapping("getAll-BiometricReports-ByDate/{date}")
	@Operation(summary = "Get All BiometricReports by Date", description = "To get All BiometricReports data based on particular Date", tags = "Get")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Data Fetched Successfully", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = BiometricReportEntity.class)) }) })
	public ResponseEntity<Map<String, Object>> getAllBiometricReportsByDate(@PathVariable Date date,
			@RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "10") Integer pageSize,
			String sortBy) {
		System.out.println("Inside getAllBiometricReportsByDate method");
		Pageable paging = PageRequest.of(pageNumber, pageSize, Sort.by("empId"));
		Map<String, Object> resMap = biometricReportServiceImpl.getAllBiometricReportsByDate(date, paging);
		return ResponseEntity.ok(resMap);

	}

	@GetMapping("/getBiometricReports-fromDatetotodate-forEmp/{empId}/{fromDate}/{toDate}")
	@Operation(summary = "Get  BiometricReports of an  Employee between Dates", description = "To get  BiometricReports of an Employee based on EmpId and fromDate to toDate", tags = "Get")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Data Fetched Successfully", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = BiometricReportEntity.class)) }) })
	public ResponseEntity<Map<String, Object>> getBiometricReportsforEmpbetweenDates(@PathVariable long empId,
			@PathVariable Date fromDate, @PathVariable Date toDate,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "10") Integer pageSize,
			@RequestParam(defaultValue = "biometricDate") String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
		Map<String, Object> reslist1 = biometricReportServiceImpl.getBioReportsFromDatetoTodateforEmp(empId, fromDate,
				toDate, paging);
		return ResponseEntity.ok(reslist1);
	}

	@GetMapping("/get-BiometricReports-ByMonthAndisLate/{month}/{year}")
	@Operation(summary = "Get  BiometricReports by Month,Year and count of isLate", description = "To get BiometricReports data based on Month,Year and count of IsLate for each employee in a month", tags = "Get")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Data Fetched Successfully", content = {
			@Content(mediaType = "application/json", schema = @Schema(implementation = BiometricReportsByDateAndisLateSuccessResponseDto.class)) }) })
	public ResponseEntity<Map<String, Object>> getLateBiometricReportByMonth(@PathVariable String month,
			@PathVariable(required = false) Integer year, @RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "10") Integer pageSize, String sortBy) {
		System.out.println("Inside getLateBiometricReportByMonth method");
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by("empId").ascending());
		Map<String, Object> resMap = biometricReportServiceImpl.getCountofisLateBiometricReportByMonth(month, year,
				paging);
		return ResponseEntity.ok(resMap);

	}

	@GetMapping("/update-islate-report/{fromDate}/{toDate}")
	public ResponseEntity<Map<String, Object>> updateBiometricIsLateReport(@PathVariable String fromDate,
			@PathVariable String toDate) throws SQLException {
		return ResponseEntity.ok(this.biometricReportServiceImpl.updateBiometricIsLateReport(
				getTimestampFromatFromString(fromDate + " 00:00:00"),
				getTimestampFromatFromString(toDate + " 00:00:00")));

	}

	private Timestamp getTimestampFromatFromString(String date) {
		try {
			String simpleDateFormat = "yyyy-MM-dd hh:mm:ss.SSS";
//			SimpleDateFormat dateFormat = new SimpleDateFormat(simpleDateFormat);
//			//java.util.Date parsedDate = dateFormat.parse(date);
//			//return new java.sql.Date(parsedDate.getTime());
			return Timestamp.valueOf(date);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	
	@GetMapping("employees-calculated-report/{fromDate}/{toDate}")
	@Operation(summary = "Get  BiometricReports of Non late Employees", description = "To get BiometricReports of employees who are not late \r\n"
			+ "	@Operation(summary = \"Get  BiometricReports of non late employees \", description = \"To get count of BiometricReports of non late employees ", tags = "Get")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Data Fetched Successfully", content = {
			@Content(mediaType = "application/json")  }) })
	public ResponseEntity<Map<String, Object>> calculatedBiometricEmployeesReport(@PathVariable String fromDate,@PathVariable String toDate, @RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "1000") Integer pageSize) {
		//System.out.println("Inside nonLateEmployeesReport method");
		
		if (!fromDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
		    throw new BadRequestException("Please enter valid from date");
		}
		if (!toDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
		    throw new BadRequestException("Please enter valid end date");
		}
		Pageable paging = PageRequest.of(pageNo, pageSize);
		Map<String, Object> resMap = biometricReportServiceImpl.calculatedBiometricEmployeesReport(paging,fromDate,toDate);
		return ResponseEntity.ok(resMap);
	}
	


}
