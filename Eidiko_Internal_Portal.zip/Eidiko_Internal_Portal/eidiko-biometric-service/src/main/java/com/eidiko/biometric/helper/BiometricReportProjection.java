package com.eidiko.biometric.helper;

public interface BiometricReportProjection {
    Long getemp_id();
    String getemp_name();
    Long getcount();
    
    
}