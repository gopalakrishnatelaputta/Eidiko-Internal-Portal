package com.eidiko.biometric.service;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface BiometricService {
	
	public ResponseEntity<Map<String, String>> uploadFile(MultipartFile file);

}
