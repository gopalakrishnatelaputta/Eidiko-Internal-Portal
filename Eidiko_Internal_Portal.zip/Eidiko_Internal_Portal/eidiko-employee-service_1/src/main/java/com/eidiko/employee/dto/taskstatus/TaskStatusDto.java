package com.eidiko.employee.dto.taskstatus;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TaskStatusDto {

	 	private long taskDetailsId;
	    private String taskDetails;
	    private String desc;
	    private long taskAssignedBy;
	    private String status;
	    private String reason;
	    private long taskVerifiedBy;
	    private Timestamp statusReportDate;
	    private String team;
	    private LocalDate assignedDate;
	
}
