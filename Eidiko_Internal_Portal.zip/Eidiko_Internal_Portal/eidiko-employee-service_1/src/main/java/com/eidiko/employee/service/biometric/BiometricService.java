package com.eidiko.employee.service.biometric;

import org.springframework.web.multipart.MultipartFile;

import com.eidiko.employee.dto.BiometricData;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

public interface BiometricService {

    public Map<String,Object> addFile(MultipartFile file,String path);

    public Map<String,Object> getBiometricReportByEmpIdFromDateToDate(String path);

    public Map<String,Object> getAllBiometricReportsByDate(String path);

    public Map<String,Object> getBiometricReportsByMonthAndIsLateCount(String path);


    public Map<String, Object> updateBiometricIsLateReport(String path) throws SQLException;
    public Map<String,Object> getBiometricReportsByMonthAndIsLate(String path);

    public Map<String, Object> getBiometricDataByIdDate(String path);
    
    public Map<String, Object> getAllBiometricReportCalculated(String path);
  
}
