package com.eidiko.employee.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.employee.entity.Designations;

public interface DesignationRepo extends JpaRepository<Designations,Integer>{
	
	
	public Designations findByDesignationName(String name);
	

}
