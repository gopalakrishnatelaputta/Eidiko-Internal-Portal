package com.eidiko.employee.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.employee.entity.ReportingManager;

public interface ReportingManagerRepo extends JpaRepository<ReportingManager, Long>{

}
