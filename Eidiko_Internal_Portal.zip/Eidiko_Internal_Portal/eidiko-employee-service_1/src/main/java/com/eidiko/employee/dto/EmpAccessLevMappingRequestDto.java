package com.eidiko.employee.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpAccessLevMappingRequestDto {

    private int accessLvlId;
    private  Long empId;
}
