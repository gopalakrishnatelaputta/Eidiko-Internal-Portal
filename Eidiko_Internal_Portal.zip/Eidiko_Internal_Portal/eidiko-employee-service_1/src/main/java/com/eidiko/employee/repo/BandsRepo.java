package com.eidiko.employee.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.employee.entity.Bands;

public interface BandsRepo extends JpaRepository<Bands, Integer>{

}
