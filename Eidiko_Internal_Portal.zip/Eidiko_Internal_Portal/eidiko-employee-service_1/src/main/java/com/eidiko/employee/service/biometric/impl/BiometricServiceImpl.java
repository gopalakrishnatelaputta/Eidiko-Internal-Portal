package com.eidiko.employee.service.biometric.impl;

import com.eidiko.employee.dto.BiometricData;
import com.eidiko.employee.exception.ResourceNotProcessedException;
import com.eidiko.employee.service.biometric.BiometricService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BiometricServiceImpl implements BiometricService {
	@Autowired
	private WebClient client;

	@SuppressWarnings("unchecked")
	@Override
    public Map<String, Object> addFile(MultipartFile file, String path) {
		MultipartBodyBuilder builder = new MultipartBodyBuilder();
		builder.part("file", file.getResource());

		String string = client.post().uri(path)
				.contentType(MediaType.MULTIPART_FORM_DATA)
				.body(BodyInserters.fromMultipartData(builder.build()))
				.exchange().flatMap(clientResponse -> {
					if (clientResponse.statusCode().is5xxServerError()) {
						clientResponse.body((clientHttpResponse, context) -> {
							return clientHttpResponse.getBody();
						});
						return clientResponse.bodyToMono(String.class);
					} else
						return clientResponse.bodyToMono(String.class);
				}).block();

        try {
            return new ObjectMapper().readValue(string, HashMap.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            throw new ResourceNotProcessedException(e.getMessage());
        }
    }

	@Override
	public Map<String, Object> getBiometricReportByEmpIdFromDateToDate(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getAllBiometricReportsByDate(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getBiometricReportsByMonthAndIsLateCount(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> updateBiometricIsLateReport(String path) throws SQLException {
		System.out.println(path);
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}

	}

	@Override
	public Map<String, Object> getBiometricReportsByMonthAndIsLate(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getBiometricDataByIdDate(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
//		try {
//
//			ObjectMapper objectMapper = new ObjectMapper();
//			// add this line
//			objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//			return objectMapper.readValue(responseFinal,
//					new TypeReference<List<BiometricData>>() {
//					});
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//			throw new ResourceNotProcessedException("nothing");
//		}
	}

	@Override
	public Map<String, Object> getAllBiometricReportCalculated(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}


}
