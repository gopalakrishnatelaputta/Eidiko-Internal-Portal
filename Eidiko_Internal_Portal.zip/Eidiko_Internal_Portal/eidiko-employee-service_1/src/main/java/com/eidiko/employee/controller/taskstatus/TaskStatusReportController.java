package com.eidiko.employee.controller.taskstatus;

import java.net.URISyntaxException;
import java.sql.Date;
import java.util.Map;

import com.eidiko.employee.config.SecurityUtil;
import com.eidiko.employee.exception.ResourceNotProcessedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eidiko.employee.dto.taskstatus.TaskStatusDto;
import com.eidiko.employee.dto.taskstatus.TaskVerifyReqDto;
import com.eidiko.employee.helper.AuthAssignedConstants;
import com.eidiko.employee.helper.ConstantValues;
import com.eidiko.employee.helper.Helper;
import com.eidiko.employee.service.taskstatus.TaskStatusService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import javax.security.sasl.AuthenticationException;

@RestController
@RequestMapping("/api/v1/daily-status-report")
public class TaskStatusReportController {

	@Autowired
	TaskStatusService taskStatusService;

	@Autowired
	private Helper helper;

	private boolean validateUser(long empId) {
		try {
			if (SecurityUtil.getCurrentUserDetails().getEmpId() == empId || this.helper.validateUserOrAuth()) {
				return true;
			}
		} catch (AuthenticationException e) {
			throw new ResourceNotProcessedException("You don't have Authority");
		}
		return false;
	}

	@PreAuthorize(AuthAssignedConstants.EMPLOYEE_LEVEL_ACCESS)
	@GetMapping("/get-report/{empId}/{fromDate}/{toDate}")
	public Map<String, Object> getPosts(@PathVariable long empId, @PathVariable Date fromDate,
			@PathVariable Date toDate, @RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = "taskDetailsId") String sortBy) throws JsonProcessingException {

//		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL
//				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE + ConstantValues.URL_SEPARATOR
//				+ empId + ConstantValues.URL_SEPARATOR + fromDate + ConstantValues.URL_SEPARATOR + toDate + ConstantValues.PAGE_NO
//				+ pageNo + ConstantValues.PAGE_SIZE + pageSize + ConstantValues.SORT_BY + sortBy;
		// String
		// path="http://192.168.1.207:9292/api/V1/dailyStatusReport/get/1000/2023-02-10/2023-05-21?pageNo=0&pageSize=3";
		if (!validateUser(empId)) {
			throw new ResourceNotProcessedException("You don't have Authority");
		}
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE + ConstantValues.URL_SEPARATOR
				+ empId + ConstantValues.URL_SEPARATOR + fromDate + ConstantValues.URL_SEPARATOR + toDate
				+ ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO + ConstantValues.QUERY_PARAM_ASSIGN + pageNo
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN
				+ pageSize + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY
				+ ConstantValues.QUERY_PARAM_ASSIGN + sortBy;

		return this.taskStatusService.getDailyStatusReportFromDateToDate(path);
	}

	@PreAuthorize(AuthAssignedConstants.EMPLOYEE_LEVEL_ACCESS)
	@PostMapping("/create-task")
	public Map<String, Object> addTask(@RequestBody TaskStatusDto taskStatusDto)
			throws URISyntaxException, JsonMappingException, JsonProcessingException {
		Long empId = null;
		try {
			empId = SecurityUtil.getCurrentUserDetails().getEmpId();
		} catch (AuthenticationException e) {
			throw new ResourceNotProcessedException(e.getMessage());
		}

		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_ADD_REPORT_FROMDATE_TODATE_RESOURCE + ConstantValues.URL_SEPARATOR
				+ empId;
		return this.taskStatusService.addTask(empId, taskStatusDto, path);

	}

	@PreAuthorize(AuthAssignedConstants.ADMIN_LEVEL_ACCESS)
	@PutMapping("/update-verified-by")
	public Map<String, Object> updateVerifiedBy(@RequestBody TaskVerifyReqDto verifyReqDto) {

		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_UPDATE_REPORT_FROMDATE_TODATE_RESOURCE;
		// http://192.168.1.207:9292/api/V1/dailyStatusReport/updateAll

		try {
			System.out.println(SecurityUtil.getCurrentUserDetails().getEmpId());
			verifyReqDto.setVerifiedById(SecurityUtil.getCurrentUserDetails().getEmpId());
		} catch (AuthenticationException e) {
			throw new ResourceNotProcessedException(e.getMessage());
		}

		return this.taskStatusService.updateVerifiedBy(verifyReqDto, path);

	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("/get-all-reports")
	public Map<String, Object> getAllReports(@RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = "taskDetailsId") String sortBy) {
		// http://192.168.1.207:9292/api/V1/dailyStatusReport/get?pageNo=0&pageSize=10
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE + ConstantValues.QUERY_PARAM
				+ ConstantValues.PAGE_NO + ConstantValues.QUERY_PARAM_ASSIGN + pageNo
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN
				+ pageSize + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY
				+ ConstantValues.QUERY_PARAM_ASSIGN + sortBy;
		return this.taskStatusService.getAllDailyStatusReports(path);
	}

	@PreAuthorize(AuthAssignedConstants.EMPLOYEE_LEVEL_ACCESS)
	@GetMapping("/get-all-reports-empId/{empId}")
	public Map<String, Object> getAllReportsByEmpId(@PathVariable long empId,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = "taskDetailsId") String sortBy) {
		// http://192.168.1.207:9292/api/V1/dailyStatusReport/get/1000?pageNo=0&pageSize=3
		if (!validateUser(empId)) {
			throw new ResourceNotProcessedException("You don't have Authority");
		}
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE + ConstantValues.URL_SEPARATOR
				+ empId + ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO + ConstantValues.QUERY_PARAM_ASSIGN
				+ pageNo + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_SIZE
				+ ConstantValues.QUERY_PARAM_ASSIGN + pageSize + ConstantValues.QUERY_PARAM_SEPARATOR
				+ ConstantValues.SORT_BY + ConstantValues.QUERY_PARAM_ASSIGN + sortBy;
		return this.taskStatusService.getAllReportsByEmpId(path);
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("/get-all-reports-between-given-dates/{fromDate}/{toDate}")
	public Map<String, Object> getAllReportsGivenDates(@PathVariable Date fromDate, @PathVariable Date toDate,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = "taskDetailsId") String sortBy) {
		// http://192.168.1.207:9292/api/V1/dailyStatusReport/get/2023-03-14/2023-05-20?pageNo=0&pageSize=3
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE + ConstantValues.URL_SEPARATOR
				+ fromDate + ConstantValues.URL_SEPARATOR + toDate + ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO
				+ ConstantValues.QUERY_PARAM_ASSIGN + pageNo + ConstantValues.QUERY_PARAM_SEPARATOR
				+ ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN + pageSize
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY + ConstantValues.QUERY_PARAM_ASSIGN
				+ sortBy;
		return this.taskStatusService.getAllReportsGivenDates(path);
	}

	@PreAuthorize(AuthAssignedConstants.ADMIN_LEVEL_ACCESS)
	@GetMapping("/get-pending-reports-by-date/{fromDate}/{toDate}")
	public Map<String, Object> getPendingReportsByDate(@PathVariable Date fromDate, @PathVariable Date toDate,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = "taskDetailsId") String sortBy) {
		// http://192.168.1.207:9292/api/V1/dailyStatusReport/getPending/2023-03-14/2023-05-03
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE
				+ ConstantValues.TASK_STATUS_SERVICE_PENDING_REPORT_FROMDATE_TODATE_RESOURCE
				+ ConstantValues.URL_SEPARATOR + fromDate + ConstantValues.URL_SEPARATOR + toDate
				+ ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO + ConstantValues.QUERY_PARAM_ASSIGN + pageNo
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN
				+ pageSize + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY
				+ ConstantValues.QUERY_PARAM_ASSIGN + sortBy;

		return this.taskStatusService.getPendingReports(path);
	}

	@PreAuthorize(AuthAssignedConstants.ADMIN_LEVEL_ACCESS)
	@GetMapping("/get-pending-status/{fromDate}/{toDate}")
	public Map<String, Object> getStatus(@PathVariable Date fromDate, @PathVariable Date toDate,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = "No") String status,
			@RequestParam(defaultValue = "taskDetailsId") String sortBy) {
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE
				+ ConstantValues.TASK_STATUS_SERVICE_STATUS_RESOURCE + ConstantValues.URL_SEPARATOR + fromDate
				+ ConstantValues.URL_SEPARATOR + toDate + ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO
				+ ConstantValues.QUERY_PARAM_ASSIGN + pageNo + ConstantValues.QUERY_PARAM_SEPARATOR
				+ ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN + pageSize
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY + ConstantValues.QUERY_PARAM_ASSIGN
				+ sortBy + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.STATUS_TEXT
				+ ConstantValues.QUERY_PARAM_ASSIGN + status;
		System.out.println(path);
		// http://192.168.1.207:9292/api/V1/dailyStatusReport/getStatus/2023-03-14/2023-05-02?status=No&pageNo=0&pageSize=10
		return this.taskStatusService.getStatusReport(path);

	}

	@PreAuthorize(AuthAssignedConstants.ADMIN_LEVEL_ACCESS)
	@GetMapping("/get-all-pending-status")
	public Map<String, Object> getAllPendingStatus(@RequestParam(defaultValue = "taskDetailsId") String sortBy,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "5") Integer pageSize) {
		// String
		// path="http://192.168.1.207:9292/api/V1/dailyStatusReport/getAllPendingStatus?status=no";
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE
				+ ConstantValues.TASK_STATUS_SERVICE_ALL_PENDING_STATUS + ConstantValues.QUERY_PARAM
				+ ConstantValues.STATUS_TEXT + ConstantValues.QUERY_PARAM_ASSIGN + ConstantValues.NO
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY + ConstantValues.QUERY_PARAM_ASSIGN
				+ sortBy + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_NO
				+ ConstantValues.QUERY_PARAM_ASSIGN + pageNo + ConstantValues.QUERY_PARAM_SEPARATOR
				+ ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN + pageSize;
		return this.taskStatusService.getAllPendingStatus(path);
	}

	@PreAuthorize(AuthAssignedConstants.ADMIN_LEVEL_ACCESS)
	@GetMapping("/get-all-pending-reports")
	public Map<String, Object> getAllPendingReports(@RequestParam(defaultValue = "taskDetailsId") String sortBy,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "5") Integer pageSize) {
		// String
		// path="http://192.168.1.207:9292/api/V1/dailyStatusReport/getAllPendingReports";
		String path = ConstantValues.TASK_STATUS_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.TASK_STATUS_SERVICE_GET_REPORT_FROMDATE_TODATE_RESOURCE
				+ ConstantValues.TASK_STATUS_SERVICE_ALL_PENDING_REPORTS + ConstantValues.QUERY_PARAM
				+ ConstantValues.SORT_BY + ConstantValues.QUERY_PARAM_ASSIGN + sortBy
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_NO + ConstantValues.QUERY_PARAM_ASSIGN
				+ pageNo + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_SIZE
				+ ConstantValues.QUERY_PARAM_ASSIGN + pageSize;
		
		return this.taskStatusService.getAllPendingReports(path);
	}

}
