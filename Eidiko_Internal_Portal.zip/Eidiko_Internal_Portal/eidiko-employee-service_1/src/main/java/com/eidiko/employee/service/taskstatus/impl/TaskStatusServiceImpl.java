package com.eidiko.employee.service.taskstatus.impl;

import java.net.ConnectException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import com.eidiko.employee.dto.taskstatus.TaskStatusDto;
import com.eidiko.employee.dto.taskstatus.TaskVerifyReqDto;
import com.eidiko.employee.exception.ResourceNotProcessedException;
import com.eidiko.employee.service.taskstatus.TaskStatusService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class TaskStatusServiceImpl implements TaskStatusService {

	@Autowired
	private WebClient client;

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getDailyStatusReportFromDateToDate(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> addTask(long empId, TaskStatusDto taskStatusDto, String path) {
		String string = client.post().uri(path).bodyValue(taskStatusDto).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();

		try {
			return new ObjectMapper().readValue(string, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> updateVerifiedBy(TaskVerifyReqDto dto, String path) {
		String string = client.put().uri(path).bodyValue(dto).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(string, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getAllDailyStatusReports(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getAllReportsByEmpId(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getAllReportsGivenDates(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getPendingReports(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getStatusReport(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getAllPendingStatus(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

	@Override
	public Map<String, Object> getAllPendingReports(String path) {
		String responseFinal = client.get().uri(path).exchange().flatMap(clientResponse -> {
			if (clientResponse.statusCode().is5xxServerError()) {
				clientResponse.body((clientHttpResponse, context) -> {
					return clientHttpResponse.getBody();
				});
				return clientResponse.bodyToMono(String.class);
			} else
				return clientResponse.bodyToMono(String.class);
		}).block();
		try {
			return new ObjectMapper().readValue(responseFinal, HashMap.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			throw new ResourceNotProcessedException(e.getMessage());
		}
	}

}
