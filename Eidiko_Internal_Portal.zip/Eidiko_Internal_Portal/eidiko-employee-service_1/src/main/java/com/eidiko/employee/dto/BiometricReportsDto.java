package com.eidiko.employee.dto;

import java.util.Date;
import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BiometricReportsDto {
	private Long biometricReportId;
	private Long empId;
	private Date biometricDate;
	private Timestamp checkInTime;
	private Timestamp checkOutTime;
	private int totalWorkingTime;
	private Boolean isLate;
	private Timestamp modifiedOn;
	private int month;
	private int year;
	
	@Override
	public String toString() {
		return "BiometricReportsDto [biometricReportId=" + biometricReportId + ", empId=" + empId + ", biometricDate="
				+ biometricDate + ", checkInTime=" + checkInTime + ", checkOutTime=" + checkOutTime
				+ ", totalWorkingTime=" + totalWorkingTime + ", isLate=" + isLate + ", modifiedOn=" + modifiedOn
				+ ", month=" + month + ", year=" + year + "]";
	}
	
}
