package com.eidiko.employee.mail;

import com.eidiko.employee.dto.EmailDetailsDto;

public interface MailService {

	
	 boolean sendSimpleMail(EmailDetailsDto details);
	 
	   
	 
	
	
}
