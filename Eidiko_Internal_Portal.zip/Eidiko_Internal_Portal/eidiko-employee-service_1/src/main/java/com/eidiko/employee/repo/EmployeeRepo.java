package com.eidiko.employee.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eidiko.employee.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {

	public Page<Employee> findAllByIsDeleted(boolean isDeleted, Pageable pageable);

	public List<Employee> findAllByEmpNameContaining(String empName);

	@Query(value = "SELECT * FROM Employee e WHERE e.emp_id LIKE %?1%" + " OR e.emp_name LIKE %?1%", nativeQuery = true)
	public List<Employee> searchEmployee(String key);

	@Query(value = "SELECT e.emp_name FROM Employee e WHERE e.emp_id = ?1", nativeQuery = true)
	public String getEmployeeName(long key);

}
