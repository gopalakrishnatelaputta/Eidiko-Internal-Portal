package com.eidiko.employee.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.employee.entity.ClientLocations;

public interface ClientLocationRepo extends JpaRepository<ClientLocations, Integer> {

}
