package com.eidiko.employee.helper;

import org.springframework.beans.factory.annotation.Value;

public class ServicesURLSAndFolderLocation {
	
	
	

}
