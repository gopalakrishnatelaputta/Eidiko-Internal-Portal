package com.eidiko.employee.controller;

import com.eidiko.employee.dto.*;
import com.eidiko.employee.entity.EmpShiftTimings;
import com.eidiko.employee.entity.Employee;
import com.eidiko.employee.exception.ResourceNotProcessedException;
import com.eidiko.employee.helper.AuthAssignedConstants;
import com.eidiko.employee.helper.ConstantValues;
import com.eidiko.employee.service.EmployeeService;
import com.eidiko.employee.service.biometric.BiometricService;

import jakarta.validation.Valid;

import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;

import javax.security.sasl.AuthenticationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v1/access")
public class AcessLvlController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	BiometricService biometricService;

	
	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@PostMapping("/employee/add-shift-timing")
	public ResponseEntity<Map<String, Object>> addShiftTimingsAccLvl(@Valid @RequestBody ShiftTimingReqDto shiftTimingReqDto)
			throws AuthenticationException {

		if(shiftTimingReqDto.getEmpId() == 0) {
			throw new ResourceNotProcessedException(ConstantValues.EMPLOYEE_ID_MUST_NOT_BE_NULL_OR_BLANK);
		}
		if (shiftTimingReqDto.getWeekOff().size() > 2)
			throw new ResourceNotProcessedException(ConstantValues.WEEKOFF_CAN_ONLY_BE_USED_FOR_TWO_DAYS);
		return ResponseEntity.ok().body(this.employeeService.addShiftTiming(shiftTimingReqDto));

	}

	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@PostMapping("employee/add-reporting-manager")
	public ResponseEntity<Map<String, Object>> addReportingManager(@RequestBody ManagerRequestDto managerRequestDto)
			throws AuthenticationException {
		if(managerRequestDto.getEmpId() == 0) {
			throw new ResourceNotProcessedException(ConstantValues.EMPLOYEE_ID_MUST_NOT_BE_NULL_OR_BLANK);
		}
		if (managerRequestDto.getEmpId() == managerRequestDto.getManagerId())
			throw new ResourceNotProcessedException(ConstantValues.EMPLOYEE_AND_MANAGER_SHOULD_NOT_BE_THE_SAME);

		return ResponseEntity.ok().body(this.employeeService.addReportingManager(managerRequestDto));
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@PostMapping("employee/add-work-location")
	public ResponseEntity<Map<String, Object>> addWorkLocation(@RequestBody EmpWorkLocationReqDto empWorkLocationReqDto)
			throws NumberFormatException, AuthenticationException {
		if(empWorkLocationReqDto.getEmpId() == 0) {
			throw new ResourceNotProcessedException(ConstantValues.EMPLOYEE_ID_MUST_NOT_BE_NULL_OR_BLANK);
		}
		return ResponseEntity.ok().body(this.employeeService.addWorkLocation(empWorkLocationReqDto));
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("employee/get-shift-timings/{empId}")
	public ResponseEntity<Map<String, Object>> getEmployeeShiftTimingsRecord(@PathVariable long empId) {
		
		return ResponseEntity.ok(this.employeeService.getEmpShiftTimingRecord(empId));
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("employee/get-reporting-manager/{empId}")
	public ResponseEntity<Map<String, Object>> getEmployeeReportingManagerRecord(@PathVariable long empId) {

		return ResponseEntity.ok(this.employeeService.getEmpReportingManagerRecord(empId));
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("employee/get-work-location/{empId}")
	public ResponseEntity<Map<String, Object>> getEmployeeWorkingLocationRecord(@PathVariable long empId) {

		return ResponseEntity.ok(this.employeeService.getEmpWorkLocationRecord(empId));
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("employee/get-reported-employees/{empId}")
	public ResponseEntity<Map<String, Object>> getReportedEmployeeRecord(@PathVariable long empId) {

		return ResponseEntity.ok(this.employeeService.getEmpReportedEmployeeRecord(empId));
	}

	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@PutMapping("employee/update-employee")
	public ResponseEntity<Map<String, Object>> updateEmployee(@Valid @RequestBody EmployeeDto employeeDto)
			throws AuthenticationException {
		return ResponseEntity.ok().body(this.employeeService.updateEmployee(employeeDto));
	}

	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@DeleteMapping("employee/delete-employee/{empId}")
	public ResponseEntity<Map<String, Object>> deleteEmployee(@PathVariable(ConstantValues.EMP_ID) long empId)
			throws AuthenticationException {
		return ResponseEntity.ok().body(this.employeeService.deleteEmployee(empId));
	}
	
	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@PostMapping("employee/update-contactno/{empId}")
	public ResponseEntity<Map<String, Object>> updateContactNo(@RequestParam String contactNo,@PathVariable long empId)
			throws NumberFormatException {
		java.util.regex.Pattern ptrn = java.util.regex.Pattern.compile("(0/91)?[5-9][0-9]{9}");
		Matcher match = ptrn.matcher(contactNo);
		if (match.find() && match.group().equals(contactNo)) {
			return ResponseEntity.ok(this.employeeService.updateEmployeeContactNo(contactNo, empId));
		} else
			throw new ResourceNotProcessedException(ConstantValues.PLEASE_ENTER_VALID_CONTACT_NUMBER);

	}
	
	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@PutMapping("employee/update-reporting-manager")
	public ResponseEntity<Map<String, Object>> updateReportingManager(@RequestBody ManagerRequestDto managerRequestDto)
			throws NumberFormatException {

		return ResponseEntity.ok().body(this.employeeService.updateReportingManager(managerRequestDto,false));
	}
	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@PutMapping("employee/update-working-location")
	public ResponseEntity<Map<String, Object>> updateWorkingLocation(
			@RequestBody EmpWorkLocationReqDto empWorkLocationReqDto) throws NumberFormatException {
		return ResponseEntity.ok().body(this.employeeService.updateWorkingLocation(empWorkLocationReqDto,false));
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@PutMapping("employee/update-shift-timing")
	public ResponseEntity<Map<String, Object>> updateShiftTiming(@Valid @RequestBody ShiftTimingReqDto shiftTimingReqDto)
			throws NumberFormatException {
		if (shiftTimingReqDto.getWeekOff().size() > 2)
			throw new ResourceNotProcessedException(ConstantValues.WEEKOFF_CAN_ONLY_BE_USED_FOR_TWO_DAYS);

		return ResponseEntity.ok().body(this.employeeService.updateShiftTimings(shiftTimingReqDto,false));
	}
	
	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@PostMapping("employee/add-from-xls")
	public ResponseEntity<Map<String, Object>> addEmployeeFromExcel(
				@RequestParam MultipartFile file
			) throws AuthenticationException{
		
		Map<String, Object> addEmployeeFromExcel = this.employeeService.addEmployeeFromExcel(file);
		return ResponseEntity.ok(addEmployeeFromExcel);
	}
	
	@PreAuthorize(AuthAssignedConstants.SUPER_ADMIN_LEVEL_ACCESS)
	@PostMapping("employee/access-level")
	public ResponseEntity<Map<String, Object>> addAccessLevel(@RequestBody EmpAccessLevMappingRequestDto empAccessLevMappingRequestDto){
		Map<String, Object> accessLevel = this.employeeService.addAccessLevel(empAccessLevMappingRequestDto.getEmpId(), empAccessLevMappingRequestDto.getAccessLvlId());
		return ResponseEntity.ok(accessLevel);
	}

	@PreAuthorize(AuthAssignedConstants.SUPER_ADMIN_LEVEL_ACCESS)
	@DeleteMapping("employee/delete-access-level/{accessLvlId}")
	public ResponseEntity<Map<String, Object>> deleteAccessLvl(@PathVariable("accessLvlId") long accessLvlId){
		Map<String, Object> deleteEmpAccess = this.employeeService.deleteEmpAccess(accessLvlId);
		return ResponseEntity.ok(deleteEmpAccess);
	}
	
}
