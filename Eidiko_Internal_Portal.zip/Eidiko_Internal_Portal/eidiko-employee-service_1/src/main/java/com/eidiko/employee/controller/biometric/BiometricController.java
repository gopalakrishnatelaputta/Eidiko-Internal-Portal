package com.eidiko.employee.controller.biometric;

import com.eidiko.employee.config.SecurityUtil;
import com.eidiko.employee.dto.BiometricData;
import com.eidiko.employee.exception.ResourceNotProcessedException;
import com.eidiko.employee.helper.AuthAssignedConstants;
import com.eidiko.employee.helper.ConstantValues;
import com.eidiko.employee.helper.Helper;
import com.eidiko.employee.service.biometric.BiometricService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.security.sasl.AuthenticationException;

@RestController
@RequestMapping("/api/v1/biometric")
public class BiometricController {
	@Autowired
	BiometricService biometricService;
	
	
	@Autowired
	private Helper helper;

	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@PostMapping("/add-file")
	public Map<String, Object> addFile(@RequestParam MultipartFile file) {
		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.BIOMETRIC_POST_FILE_UPLOAD_RESOURCE;
		return this.biometricService.addFile(file, path);
	}

	private boolean validateUser(long empId) {
		try {
			if(SecurityUtil.getCurrentUserDetails().getEmpId() == empId || this.helper.validateUserOrAuth() ) {
				return true;
			}
		} catch (AuthenticationException e) {
			throw new ResourceNotProcessedException("You don't have Authority");
		}
		return false;
	}
	
	@GetMapping("/get-biometric-report-empid-fromdate-todate/{empId}/{fromDate}/{toDate}")
	public Map<String, Object> getBiometricDataByEmpIdFromDateToDate(@PathVariable long empId,
			@PathVariable Date fromDate, @PathVariable Date toDate, @RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "1000") Integer pageSize,
			@RequestParam(defaultValue = ConstantValues.EMP_ID) String sortBy) {
		if(!validateUser(empId)) {
			throw new ResourceNotProcessedException("You don't have Authority");
		}
		
		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.BIOMETRIC_GET_REPORT_FROMDATE_TODATE_BYEMPID + ConstantValues.URL_SEPARATOR + empId
				+ ConstantValues.URL_SEPARATOR + fromDate + ConstantValues.URL_SEPARATOR + toDate
				+ ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO + ConstantValues.QUERY_PARAM_ASSIGN + pageNo
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN
				+ pageSize + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY
				+ ConstantValues.QUERY_PARAM_ASSIGN + sortBy;
		System.out.println(path);
		return this.biometricService.getBiometricReportByEmpIdFromDateToDate(path);
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("/get-biometric-report-bydate/{date}")
	public Map<String, Object> getAllBiometricReportsByDate(@PathVariable Date date,
			@RequestParam(defaultValue = "0") Integer pageNo, @RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = ConstantValues.EMP_ID) String sortBy) {
		
		
		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.BIOMETRIC_GET_ALL_BYDATE + ConstantValues.URL_SEPARATOR + date
				+ ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO + ConstantValues.QUERY_PARAM_ASSIGN + pageNo
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN
				+ pageSize + ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY
				+ ConstantValues.QUERY_PARAM_ASSIGN + sortBy;
		return this.biometricService.getAllBiometricReportsByDate(path);
	}

	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("/get-biometric-report-bymonthandyearcount/{month}/{year}")
	public Map<String, Object> getBiometricReportsByMonthAndIsLateCount(@PathVariable String month,
			@PathVariable Integer year, @RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = ConstantValues.EMP_ID) String sortBy) {
		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.BIOMETRIC_GET_BYMONTH_YEAR + ConstantValues.URL_SEPARATOR + month
				+ ConstantValues.URL_SEPARATOR + year + ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO
				+ ConstantValues.QUERY_PARAM_ASSIGN + pageNo + ConstantValues.QUERY_PARAM_SEPARATOR
				+ ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN + pageSize
				+ ConstantValues.QUERY_PARAM_SEPARATOR + ConstantValues.SORT_BY + ConstantValues.QUERY_PARAM_ASSIGN
				+ sortBy;
		return this.biometricService.getBiometricReportsByMonthAndIsLateCount(path);
	}

//not there
	@PreAuthorize(AuthAssignedConstants.MANAGER_LEVEL_ACCESS)
	@GetMapping("/get-biometric-report-bymonthandyear/{month}/{year}")
	public Map<String, Object> getBiometricReportsByMonthAndIsLate(@PathVariable String month,
			@PathVariable Integer year, @RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "5") Integer pageSize,
			@RequestParam(defaultValue = ConstantValues.EMP_ID) String sortBy) {
		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.BIOMETRIC_GET_BYMONTH_ANDISMONTH + ConstantValues.URL_SEPARATOR + month
				+ ConstantValues.URL_SEPARATOR + year + ConstantValues.PAGE_NO + pageNo + ConstantValues.PAGE_SIZE
				+ pageSize + ConstantValues.SORT_BY + sortBy;
		return this.biometricService.getBiometricReportsByMonthAndIsLate(path);
	}

	
	@GetMapping("/get-biometric-data-by-id-date/{empId}/{fromDate}/{toDate}")
	public Map<String, Object> getBiometricDataByIdDate(@PathVariable long empId, @PathVariable String fromDate,
			@PathVariable String toDate) {
		if(!validateUser(empId)) {
			throw new ResourceNotProcessedException("You don't have Authority");
		}
		
		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.BIOMETRIC_GET_BIOMETRIC_DATA_BY_ID_DATE + ConstantValues.URL_SEPARATOR + empId
				+ ConstantValues.URL_SEPARATOR + fromDate + ConstantValues.URL_SEPARATOR + toDate
			;
		
		System.out.println(path);
		return this.biometricService.getBiometricDataByIdDate(path);
	}

	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@PutMapping("/update-islate-report/{fromDate}/{toDate}")
	public ResponseEntity<Map<String, Object>> updateBiometricIsLateReport(@PathVariable String fromDate,
			@PathVariable String toDate) throws SQLException {

		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.BIOMETRIC_UPDATE_LATE_REPORT_RESOURCE + ConstantValues.URL_SEPARATOR + fromDate
				+ ConstantValues.URL_SEPARATOR + toDate;

		return ResponseEntity.ok(this.biometricService.updateBiometricIsLateReport(path));

	}

	@PreAuthorize(AuthAssignedConstants.HR_LEVEL_ACCESS)
	@GetMapping("/get-all-biometric-report/calculated-report/{fromDate}/{toDate}")
	public Map<String, Object> getAllBiometricReportCalculated(@PathVariable String fromDate, @PathVariable String toDate,
			@RequestParam(defaultValue = "1000") Integer pageSize, @RequestParam(defaultValue = "0") Integer pageNo) {

		String path = ConstantValues.BIOMETRIC_SERVICE_BASE_URL + ConstantValues.URL_SEPARATOR
				+ ConstantValues.EMPLOYEES_CALCULATE_REPORT_RESOURCE + ConstantValues.URL_SEPARATOR + fromDate
				+ ConstantValues.URL_SEPARATOR + toDate + ConstantValues.QUERY_PARAM + ConstantValues.PAGE_NO
				+ ConstantValues.QUERY_PARAM_ASSIGN + pageNo + ConstantValues.QUERY_PARAM_SEPARATOR
				+ ConstantValues.PAGE_SIZE + ConstantValues.QUERY_PARAM_ASSIGN + pageSize;
		System.out.println(path);

		return this.biometricService.getAllBiometricReportCalculated(path);

	}
	
	
}
