package com.eidiko.employee.repo;

import com.eidiko.employee.entity.EmpAccessLvlMapping;
import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.employee.entity.EmployeeAccessLevel;

import java.util.List;
import java.util.Optional;

public interface EmpAccessLvlRepo extends JpaRepository<EmployeeAccessLevel, Integer>{

    EmployeeAccessLevel findByAccessLvlIdIn(List<Integer> accessLvlId);
}
