package com.eidiko.employee.service.taskstatus;

import java.net.URISyntaxException;
import java.util.Map;

import com.eidiko.employee.dto.taskstatus.TaskStatusDto;
import com.eidiko.employee.dto.taskstatus.TaskVerifyReqDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface TaskStatusService {

	
	public Map<String, Object> getDailyStatusReportFromDateToDate(String path) throws JsonMappingException, JsonProcessingException;
	
	
	public Map<String, Object> addTask(long empId,TaskStatusDto taskStatusDto, String path) throws URISyntaxException,JsonMappingException, JsonProcessingException;


	public Map<String, Object> updateVerifiedBy(TaskVerifyReqDto dto,String path);
	
	
	public Map<String,Object> getAllDailyStatusReports(String path) ;


	public Map<String,Object> getAllReportsByEmpId(String path) ;


	public Map<String,Object> getAllReportsGivenDates(String path);

	public Map<String,Object> getPendingReports(String path);

	public Map<String,Object> getStatusReport(String path);

	public Map<String,Object> getAllPendingStatus(String path);

	public Map<String,Object> getAllPendingReports(String path);
	
}
