package com.eidiko.employee.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eidiko.employee.entity.EmpShiftTimings;

public interface EmpShiftTimingRepo extends JpaRepository<EmpShiftTimings, Long> {

}
